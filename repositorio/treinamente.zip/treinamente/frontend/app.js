"use strict";

// O estado fica apenas nesta aba; fechar o navegador descarta o token guardado no sessionStorage.
const API = document.querySelector('meta[name="api-base"]').content.replace(/\/$/, "");
const state = { token: sessionStorage.getItem("treinamente_token"), usuario: null, aulas: [], aulaId: null };
const byId = (id) => document.getElementById(id);
const texto = (tag, value, className) => { const el = document.createElement(tag); el.textContent = value ?? ""; if (className) el.className = className; return el; };

function configurarSeo() {
  // Canonical e schema usam a origem real para o mesmo build funcionar em ambientes diferentes.
  const canonical = byId("canonical-url");
  canonical.href = new URL("/", location.origin).href;
  const ogUrl = document.createElement("meta");
  ogUrl.setAttribute("property", "og:url"); ogUrl.content = canonical.href; document.head.append(ogUrl);
  const schema = document.createElement("script"); schema.type = "application/ld+json";
  schema.textContent = JSON.stringify({ "@context": "https://schema.org", "@type": "WebApplication", name: "TreinaMente", url: canonical.href, applicationCategory: "EducationalApplication", operatingSystem: "Web", inLanguage: "pt-BR", description: document.querySelector('meta[name="description"]').content });
  document.head.append(schema);
}

async function api(path, options = {}) {
  // Toda chamada passa por aqui para manter autenticacao e mensagens de erro consistentes.
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const response = await fetch(`${API}${path}`, { ...options, headers });
  const type = response.headers.get("content-type") || "";
  const data = type.includes("application/json") ? await response.json() : null;
  if (!response.ok) {
    // Um 401 invalida o estado local antes que a interface continue exibindo dados privados.
    if (response.status === 401 && state.token) encerrarSessao(false);
    throw new Error(data?.mensagem || `Falha na operacao (${response.status}).`);
  }
  return data;
}

function feedback(element, message, type = "") {
  element.textContent = message;
  element.className = `form-feedback ${type}`.trim();
}

function abrirAcesso(registro = false) {
  byId("acesso").hidden = false;
  selecionarAba(registro ? "registro" : "login");
  byId("acesso").scrollIntoView({ behavior: "smooth", block: "start" });
}

function selecionarAba(nome) {
  const registro = nome === "registro";
  byId("painel-login").hidden = registro;
  byId("painel-registro").hidden = !registro;
  byId("tab-login").setAttribute("aria-selected", String(!registro));
  byId("tab-registro").setAttribute("aria-selected", String(registro));
  (registro ? byId("registro-nome") : byId("login-email")).focus();
}

async function entrar(event) {
  event.preventDefault();
  const form = event.currentTarget;
  try {
    feedback(byId("auth-feedback"), "Entrando...");
    const data = await api("/auth/login", { method: "POST", body: JSON.stringify({ email: form.email.value, senha: form.senha.value }) });
    state.token = data.token; state.usuario = data.usuario;
    sessionStorage.setItem("treinamente_token", state.token);
    await abrirWorkspace();
  } catch (error) { feedback(byId("auth-feedback"), error.message, "error"); }
}

async function registrar(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form));
  try {
    feedback(byId("auth-feedback"), "Criando conta...");
    const data = await api("/auth/registro", { method: "POST", body: JSON.stringify(payload) });
    let message = data.mensagem;
    if (data.tokenDesenvolvimento) message += ` Token local: ${data.tokenDesenvolvimento}`;
    feedback(byId("auth-feedback"), message, "success");
    form.reset(); selecionarAba("login");
  } catch (error) { feedback(byId("auth-feedback"), error.message, "error"); }
}

async function abrirWorkspace() {
  if (!state.usuario) state.usuario = await api("/auth/me");
  document.querySelectorAll("main > section:not(#workspace)").forEach(section => section.hidden = true);
  document.querySelector(".site-header").hidden = true;
  document.querySelector("footer").hidden = true;
  byId("workspace").hidden = false;
  byId("usuario-nome").textContent = state.usuario.nome;
  byId("workspace-perfil").textContent = state.usuario.perfil === "ALUNO" ? "Area do estudante" : "Area do professor";
  // Administrador compartilha os controles de gestao, mas continua identificado pelo backend.
  const professor = state.usuario.perfil === "PROFESSOR" || state.usuario.perfil === "ADMIN";
  byId("nova-aula").hidden = !professor;
  byId("metricas").hidden = !professor;
  await Promise.all([carregarAulas(), professor ? carregarDashboard() : Promise.resolve()]);
}

function encerrarSessao(recarregar = true) {
  const token = state.token;
  state.token = null; state.usuario = null; state.aulas = []; state.aulaId = null;
  sessionStorage.removeItem("treinamente_token");
  // A limpeza local nao depende da rede; a revogacao remota e uma tentativa adicional.
  if (token) fetch(`${API}/auth/logout`, { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }).catch(() => {});
  if (recarregar) location.assign("/");
}

async function carregarAulas() {
  state.aulas = await api("/aulas");
  const lista = byId("lista-aulas"); lista.replaceChildren();
  if (!state.aulas.length) { lista.append(texto("p", "Nenhuma aula por enquanto.", "empty-state")); return; }
  state.aulas.forEach(aula => {
    const button = document.createElement("button"); button.type = "button"; button.className = "class-item";
    button.setAttribute("aria-current", String(state.aulaId === aula.id));
    button.append(texto("strong", aula.titulo), texto("span", `${aula.alunos.length} estudante(s)`));
    button.addEventListener("click", () => selecionarAula(aula.id)); lista.append(button);
  });
}

async function carregarDashboard() {
  const data = await api("/dashboard");
  byId("metrica-aulas").textContent = data.aulas;
  byId("metrica-alunos").textContent = data.alunos;
  byId("metrica-mensagens").textContent = data.mensagens;
}

async function selecionarAula(id) {
  try {
    state.aulaId = id;
    const [aula, mensagens] = await Promise.all([api(`/aulas/${id}`), api(`/aulas/${id}/mensagens`)]);
    renderizarAula(aula, mensagens); await carregarAulas();
  } catch (error) { feedback(byId("app-feedback"), error.message, "error"); }
}

function renderizarAula(aula, mensagens) {
  // textContent e elementos criados pela DOM evitam interpretar conteudo de usuarios como HTML.
  const stage = byId("aula-selecionada"); stage.replaceChildren();
  const header = texto("header", "", "lesson-header");
  header.append(texto("p", aula.professor.nome, "eyebrow"), texto("h2", aula.titulo), texto("p", aula.descricao || "Sem descricao.", "lesson-meta"));
  const copy = texto("div", aula.conteudoAtual || "O professor ainda nao publicou o conteudo desta aula.", "live-copy"); copy.id = "conteudo-publicado";
  stage.append(header, copy);
  const podeGerenciar = state.usuario.perfil === "ADMIN" || aula.professor.id === state.usuario.id;
  if (podeGerenciar) stage.append(criarControlesProfessor(aula));
  stage.append(criarChat(mensagens));
}

function criarControlesProfessor(aula) {
  // A interface esconde os controles, mas a autorizacao real ainda e repetida pelo servidor.
  const area = texto("section", "", "teacher-controls"); area.setAttribute("aria-label", "Controles do professor");
  const contentForm = document.createElement("form");
  const label = texto("label", "Conteudo apresentado na aula"); const field = document.createElement("textarea"); field.rows = 6; field.maxLength = 30000; field.value = aula.conteudoAtual || ""; label.append(field);
  const save = texto("button", "Publicar atualizacao", "button"); save.type = "submit"; contentForm.append(label, save);
  contentForm.addEventListener("submit", async event => { event.preventDefault(); try { await api(`/aulas/${aula.id}/conteudo`, { method: "PUT", body: JSON.stringify({ conteudo: field.value }) }); await selecionarAula(aula.id); } catch (error) { feedback(byId("app-feedback"), error.message, "error"); } });
  const enrollForm = texto("form", "", "inline-form"); const enrollLabel = texto("label", "Adicionar estudante pelo e-mail"); const email = document.createElement("input"); email.type = "email"; email.required = true; enrollLabel.append(email); const enroll = texto("button", "Adicionar", "button"); enroll.type = "submit"; enrollForm.append(enrollLabel, enroll);
  enrollForm.addEventListener("submit", async event => { event.preventDefault(); try { await api(`/aulas/${aula.id}/alunos`, { method: "POST", body: JSON.stringify({ email: email.value }) }); await selecionarAula(aula.id); } catch (error) { feedback(byId("app-feedback"), error.message, "error"); } });
  area.append(contentForm, enrollForm); return area;
}

function criarChat(mensagens) {
  const chat = texto("section", "", "chat"); chat.append(texto("h3", "Conversa da aula"));
  const list = texto("ol", "", "chat-list"); list.id = "mensagens-aula";
  mensagens.forEach(item => { const li = document.createElement("li"); const name = texto("strong", item.autor.nome); const time = document.createElement("time"); time.dateTime = item.criadaEm; time.textContent = new Date(item.criadaEm).toLocaleString("pt-BR"); li.append(name, time, texto("p", item.texto)); list.append(li); });
  if (!mensagens.length) list.append(texto("li", "A conversa ainda nao comecou.", "empty-state"));
  const form = texto("form", "", "inline-form"); const label = texto("label", "Enviar mensagem"); const input = document.createElement("input"); input.maxLength = 2000; input.required = true; label.append(input); const submit = texto("button", "Enviar", "button"); submit.type = "submit"; form.append(label, submit);
  form.addEventListener("submit", async event => { event.preventDefault(); try { await api(`/aulas/${state.aulaId}/mensagens`, { method: "POST", body: JSON.stringify({ texto: input.value }) }); await selecionarAula(state.aulaId); } catch (error) { feedback(byId("app-feedback"), error.message, "error"); } });
  chat.append(list, form); return chat;
}

async function criarAula(event) {
  event.preventDefault();
  try {
    const aula = await api("/aulas", { method: "POST", body: JSON.stringify({ titulo: byId("aula-titulo").value, descricao: byId("aula-descricao").value }) });
    byId("dialogo-aula").close(); event.currentTarget.reset(); await carregarAulas(); await selecionarAula(aula.id);
  } catch (error) { feedback(byId("app-feedback"), error.message, "error"); }
}

async function perguntarIa(event) {
  event.preventDefault(); const output = byId("resposta-ia"); output.textContent = "Consultando...";
  try { const data = await api("/ia/perguntar", { method: "POST", body: JSON.stringify({ pergunta: byId("pergunta-ia").value }) }); output.textContent = data.resposta; }
  catch (error) { output.textContent = error.message; }
}

async function pesquisar(event) {
  event.preventDefault(); const list = byId("resultados-pesquisa"); list.replaceChildren(texto("li", "Pesquisando..."));
  try {
    const data = await api(`/pesquisas?q=${encodeURIComponent(byId("consulta-pesquisa").value)}`); list.replaceChildren();
    // noopener/noreferrer impede que uma fonte externa controle a aba do TreinaMente.
    data.resultados.forEach(item => { const li = document.createElement("li"); const link = texto("a", item.titulo); link.href = item.link; link.target = "_blank"; link.rel = "noopener noreferrer"; li.append(link, texto("p", item.resumo)); list.append(li); });
    if (!data.resultados.length) list.append(texto("li", "Nenhum resultado encontrado."));
  } catch (error) { list.replaceChildren(texto("li", error.message)); }
}

async function recuperarSenha(event) {
  event.preventDefault();
  try { const data = await api("/auth/recuperar-senha", { method: "POST", body: JSON.stringify({ email: byId("recuperacao-email").value }) }); byId("recuperacao-feedback").textContent = data.mensagem; }
  catch (error) { byId("recuperacao-feedback").textContent = error.message; }
}

async function processarAcaoUrl() {
  // O token sai da barra depois do uso para nao permanecer no historico ou em capturas de tela.
  const params = new URLSearchParams(location.search); const acao = params.get("acao"); const token = params.get("token");
  if (!acao || !token) return;
  abrirAcesso(false);
  try {
    if (acao === "verificar") { const data = await api("/auth/verificar-email", { method: "POST", body: JSON.stringify({ token }) }); feedback(byId("auth-feedback"), data.mensagem, "success"); }
    if (acao === "redefinir") {
      const senha = window.prompt("Digite a nova senha (8+ caracteres, com letras e numeros):");
      if (senha) { const data = await api("/auth/redefinir-senha", { method: "POST", body: JSON.stringify({ token, novaSenha: senha }) }); feedback(byId("auth-feedback"), data.mensagem, "success"); }
    }
    history.replaceState({}, "", location.pathname);
  } catch (error) { feedback(byId("auth-feedback"), error.message, "error"); }
}

function ligarEventos() {
  byId("abrir-login").addEventListener("click", () => abrirAcesso(false)); byId("comecar-agora").addEventListener("click", () => abrirAcesso(true));
  byId("tab-login").addEventListener("click", () => selecionarAba("login")); byId("tab-registro").addEventListener("click", () => selecionarAba("registro"));
  byId("painel-login").addEventListener("submit", entrar); byId("painel-registro").addEventListener("submit", registrar);
  byId("sair").addEventListener("click", () => encerrarSessao()); byId("nova-aula").addEventListener("click", () => byId("dialogo-aula").showModal());
  byId("form-nova-aula").addEventListener("submit", criarAula); byId("form-ia").addEventListener("submit", perguntarIa); byId("form-pesquisa").addEventListener("submit", pesquisar);
  byId("esqueci-senha").addEventListener("click", () => byId("dialogo-recuperacao").showModal()); byId("form-recuperacao").addEventListener("submit", recuperarSenha);
}

async function iniciar() {
  configurarSeo(); ligarEventos(); await processarAcaoUrl();
  if (state.token) { try { await abrirWorkspace(); } catch { encerrarSessao(false); } }
  // Alunos recebem a explicacao atualizada sem recarregar; dez segundos evita pressionar a API.
  setInterval(async () => { if (state.aulaId && state.usuario?.perfil === "ALUNO") { try { const aula = await api(`/aulas/${state.aulaId}`); byId("conteudo-publicado").textContent = aula.conteudoAtual || "O professor ainda nao publicou o conteudo desta aula."; } catch { /* proxima interacao exibe o erro */ } } }, 10000);
}

iniciar();
