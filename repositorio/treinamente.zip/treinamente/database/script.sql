-- Script idempotente para montar o banco completo em uma instalacao nova.
CREATE DATABASE IF NOT EXISTS treinamente_banco;
USE treinamente_banco;

CREATE TABLE IF NOT EXISTS instituicoes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(160) NOT NULL,
    codigo VARCHAR(40) NOT NULL UNIQUE,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cadastro (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    perfil VARCHAR(20) NOT NULL DEFAULT 'ALUNO',
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    email_verificado BOOLEAN NOT NULL DEFAULT FALSE,
    instituicao_id BIGINT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_cadastro_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicoes(id)
);

CREATE TABLE IF NOT EXISTS aulas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(160) NOT NULL,
    descricao VARCHAR(1000),
    conteudo_atual TEXT,
    ativa BOOLEAN NOT NULL DEFAULT TRUE,
    professor_id BIGINT NOT NULL,
    instituicao_id BIGINT NOT NULL,
    versao BIGINT NOT NULL DEFAULT 0,
    criada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_aula_professor FOREIGN KEY (professor_id) REFERENCES cadastro(id),
    CONSTRAINT fk_aula_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicoes(id)
);

CREATE TABLE IF NOT EXISTS aula_alunos (
    aula_id BIGINT NOT NULL,
    aluno_id BIGINT NOT NULL,
    PRIMARY KEY (aula_id, aluno_id),
    -- A matricula nao faz sentido sem a aula ou a conta, entao a limpeza acompanha o registro pai.
    CONSTRAINT fk_aula_alunos_aula FOREIGN KEY (aula_id) REFERENCES aulas(id) ON DELETE CASCADE,
    CONSTRAINT fk_aula_alunos_usuario FOREIGN KEY (aluno_id) REFERENCES cadastro(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS mensagens (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    aula_id BIGINT NOT NULL,
    autor_id BIGINT NOT NULL,
    texto VARCHAR(2000) NOT NULL,
    criada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mensagem_aula FOREIGN KEY (aula_id) REFERENCES aulas(id) ON DELETE CASCADE,
    CONSTRAINT fk_mensagem_autor FOREIGN KEY (autor_id) REFERENCES cadastro(id)
);

CREATE TABLE IF NOT EXISTS tokens_autenticacao (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    -- SHA-256 em hexadecimal tem 64 caracteres; o token puro nunca e salvo.
    token_hash CHAR(64) NOT NULL UNIQUE,
    usuario_id BIGINT NOT NULL,
    expira_em TIMESTAMP NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_token_usuario FOREIGN KEY (usuario_id) REFERENCES cadastro(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tokens_conta (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    token_hash CHAR(64) NOT NULL UNIQUE,
    tipo VARCHAR(30) NOT NULL,
    usuario_id BIGINT NOT NULL,
    expira_em TIMESTAMP NOT NULL,
    usado_em TIMESTAMP NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_token_conta_usuario FOREIGN KEY (usuario_id) REFERENCES cadastro(id) ON DELETE CASCADE
);

-- Estes indices acompanham as consultas mais frequentes de aula, chat e autenticacao.
CREATE INDEX idx_aulas_professor ON aulas(professor_id);
CREATE INDEX idx_mensagens_aula_criada ON mensagens(aula_id, criada_em);
CREATE INDEX idx_tokens_auth_hash ON tokens_autenticacao(token_hash);
CREATE INDEX idx_tokens_conta_hash ON tokens_conta(token_hash);
