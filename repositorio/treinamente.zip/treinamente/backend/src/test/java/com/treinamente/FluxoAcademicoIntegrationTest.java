package com.treinamente;

import com.fasterxml.jackson.databind.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
// Exercita o fluxo HTTP completo para confirmar que autenticacao e perfis funcionam juntos.
class FluxoAcademicoIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;
    @MockBean JavaMailSender mailSender;

    @Test
    void professorRegistraEntraECriaAula() throws Exception {
        // O caminho feliz atravessa cadastro, login e uma rota protegida com o token emitido.
        String email = "professor@umc.test";
        mvc.perform(post("/api/auth/registro").contentType(MediaType.APPLICATION_JSON).content("""
                {"nome":"Professora Ana","email":"%s","senha":"Senha1234","perfil":"PROFESSOR","instituicaoNome":"UMC"}
                """.formatted(email)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.usuario.perfil").value("PROFESSOR"))
                .andExpect(jsonPath("$.usuario.instituicaoNome").value("UMC"));

        String corpoLogin = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"senha\":\"Senha1234\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String token = mapper.readTree(corpoLogin).path("token").asText();

        mvc.perform(post("/api/aulas").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"titulo\":\"Biomecanica aplicada\",\"descricao\":\"Aula introdutoria\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.titulo").value("Biomecanica aplicada"));
    }

    @Test
    void alunoNaoPodeCriarAula() throws Exception {
        // Este teste protege a barreira mais importante entre estudante e professor.
        String email = "aluno@umc.test";
        mvc.perform(post("/api/auth/registro").contentType(MediaType.APPLICATION_JSON).content("""
                {"nome":"Aluno Joao","email":"%s","senha":"Senha1234","perfil":"ALUNO","instituicaoNome":"UMC"}
                """.formatted(email)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.usuario.perfil").value("ALUNO"))
                .andExpect(jsonPath("$.usuario.instituicaoNome").value("UMC"));
        String login = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"senha\":\"Senha1234\"}"))
                .andReturn().getResponse().getContentAsString();
        String token = mapper.readTree(login).path("token").asText();
        mvc.perform(post("/api/aulas").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"titulo\":\"Aula indevida\"}"))
                .andExpect(status().isForbidden());
    }
}
