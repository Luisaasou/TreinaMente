package com.treinamente.dto;

import com.treinamente.model.*;
import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.List;

// Records mantem o contrato HTTP pequeno e impedem que as entidades JPA vazem diretamente pela API.
public final class ApiDtos {
    private ApiDtos() {}

    public record RegistroRequest(
            @NotBlank @Size(max = 100) String nome,
            @NotBlank @Email @Size(max = 160) String email,
            @NotBlank @Size(min = 8, max = 72) String senha,
            @NotNull Perfil perfil,
            @NotBlank @Size(max = 160) String instituicaoNome,
            @Pattern(regexp = "[A-Za-z0-9_-]{3,40}") String instituicaoCodigo) {}

    public record LoginRequest(@NotBlank @Email String email, @NotBlank String senha) {}
    public record TokenRequest(@NotBlank String token) {}
    public record RecuperarSenhaRequest(@NotBlank @Email String email) {}
    public record RedefinirSenhaRequest(@NotBlank String token, @NotBlank @Size(min = 8, max = 72) String novaSenha) {}

    public record UsuarioResponse(Long id, String nome, String email, Perfil perfil,
                                  boolean emailVerificado, Long instituicaoId, String instituicaoNome) {
        public static UsuarioResponse from(Usuario usuario) {
            // A instituicao pode estar ausente em dados antigos migrados, por isso o retorno aceita null.
            Instituicao instituicao = usuario.getInstituicao();
            return new UsuarioResponse(usuario.getId(), usuario.getNome(), usuario.getEmail(), usuario.getPerfil(),
                    usuario.isEmailVerificado(), instituicao == null ? null : instituicao.getId(),
                    instituicao == null ? null : instituicao.getNome());
        }
    }

    public record RegistroResponse(String mensagem, UsuarioResponse usuario, String tokenDesenvolvimento) {}
    public record LoginResponse(String token, Instant expiraEm, UsuarioResponse usuario) {}
    public record MensagemResponse(String mensagem) {}

    public record CriarAulaRequest(@NotBlank @Size(max = 160) String titulo,
                                   @Size(max = 1000) String descricao) {}
    public record AtualizarConteudoRequest(@NotNull @Size(max = 30000) String conteudo) {}
    public record MatricularAlunoRequest(@NotBlank @Email String email) {}
    public record EnviarMensagemRequest(@NotBlank @Size(max = 2000) String texto) {}

    public record AulaResponse(Long id, String titulo, String descricao, String conteudoAtual, boolean ativa,
                               long versao, Instant atualizadaEm, UsuarioResponse professor,
                               List<UsuarioResponse> alunos) {
        public static AulaResponse from(Aula aula) {
            return new AulaResponse(aula.getId(), aula.getTitulo(), aula.getDescricao(), aula.getConteudoAtual(),
                    aula.isAtiva(), aula.getVersao(), aula.getAtualizadaEm(), UsuarioResponse.from(aula.getProfessor()),
                    aula.getAlunos().stream().map(UsuarioResponse::from).toList());
        }
    }

    public record ChatResponse(Long id, String texto, Instant criadaEm, UsuarioResponse autor) {
        public static ChatResponse from(Mensagem mensagem) {
            return new ChatResponse(mensagem.getId(), mensagem.getTexto(), mensagem.getCriadaEm(),
                    UsuarioResponse.from(mensagem.getAutor()));
        }
    }

    public record PerguntaIaRequest(@NotBlank @Size(max = 2000) String pergunta) {}
    public record RespostaIaResponse(String resposta, boolean alertaSaude, String aviso) {}
    public record PesquisaItem(String titulo, String link, String resumo) {}
    public record PesquisaResponse(String consulta, List<PesquisaItem> resultados) {}
    public record DashboardResponse(long aulas, long alunos, long mensagens, long professores) {}
}
