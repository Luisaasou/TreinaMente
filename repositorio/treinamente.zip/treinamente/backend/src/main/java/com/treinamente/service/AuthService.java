package com.treinamente.service;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.exception.AppException;
import com.treinamente.model.*;
import com.treinamente.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.text.Normalizer;
import java.util.Locale;

@Service
// Concentra o ciclo da conta para manter cadastro, verificacao e recuperacao com as mesmas regras.
public class AuthService {
    private final UsuarioRepository usuarios;
    private final InstituicaoRepository instituicoes;
    private final PasswordEncoder passwordEncoder;
    private final TokenService tokens;
    private final NotificacaoService notificacoes;
    private final boolean exporTokens;
    private final boolean exigirVerificacao;

    public AuthService(UsuarioRepository usuarios, InstituicaoRepository instituicoes,
                       PasswordEncoder passwordEncoder, TokenService tokens,
                       NotificacaoService notificacoes,
                       @Value("${app.notifications.expose-tokens:false}") boolean exporTokens,
                       @Value("${app.auth.require-email-verification:false}") boolean exigirVerificacao) {
        this.usuarios = usuarios;
        this.instituicoes = instituicoes;
        this.passwordEncoder = passwordEncoder;
        this.tokens = tokens;
        this.notificacoes = notificacoes;
        this.exporTokens = exporTokens;
        this.exigirVerificacao = exigirVerificacao;
    }

    @Transactional
    public RegistroResponse registrar(RegistroRequest request) {
        // Administradores so nascem pelo bootstrap; nunca por uma requisicao publica.
        if (request.perfil() == Perfil.ADMIN) {
            throw new AppException(HttpStatus.FORBIDDEN, "Contas administrativas nao podem ser autocadastradas.");
        }
        validarSenha(request.senha());
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        if (usuarios.findByEmailIgnoreCase(email).isPresent()) {
            throw new AppException(HttpStatus.CONFLICT, "E-mail ja cadastrado.");
        }

        // Clientes antigos ainda podem enviar o codigo; na tela atual ele nasce do nome da instituicao.
        String origemCodigo = request.instituicaoCodigo() == null || request.instituicaoCodigo().isBlank()
                ? request.instituicaoNome() : request.instituicaoCodigo();
        String codigo = normalizarCodigo(origemCodigo);
        // O codigo interno permite reaproveitar uma instituicao sem depender de maiusculas ou acentos.
        Instituicao instituicao = instituicoes.findByCodigoIgnoreCase(codigo).orElseGet(() -> {
            Instituicao nova = new Instituicao();
            nova.setNome(request.instituicaoNome().trim());
            nova.setCodigo(codigo);
            return instituicoes.save(nova);
        });

        Usuario usuario = new Usuario();
        usuario.setNome(request.nome().trim());
        usuario.setEmail(email);
        usuario.setSenha(passwordEncoder.encode(request.senha()));
        usuario.setPerfil(request.perfil());
        usuario.setInstituicao(instituicao);
        usuarios.save(usuario);

        TokenService.TokenEmitido verificacao = tokens.criarTokenConta(usuario, TokenConta.Tipo.VERIFICACAO_EMAIL);
        notificacoes.enviarVerificacao(email, verificacao.valor());
        return new RegistroResponse("Cadastro realizado. Verifique o e-mail para confirmar a conta.",
                UsuarioResponse.from(usuario), exporTokens ? verificacao.valor() : null);
    }

    @Transactional
    public LoginResponse login(LoginRequest request) {
        Usuario usuario = usuarios.findByEmailIgnoreCase(request.email().trim())
                .orElseThrow(() -> credenciaisInvalidas());
        if (!usuario.isAtivo() || !passwordEncoder.matches(request.senha(), usuario.getSenha())) {
            throw credenciaisInvalidas();
        }
        if (exigirVerificacao && !usuario.isEmailVerificado()) {
            throw new AppException(HttpStatus.FORBIDDEN, "Confirme seu e-mail antes de entrar.");
        }
        TokenService.TokenEmitido token = tokens.criarSessao(usuario);
        return new LoginResponse(token.valor(), token.expiraEm(), UsuarioResponse.from(usuario));
    }

    @Transactional
    public void verificarEmail(String token) {
        Usuario usuario = tokens.consumirTokenConta(token, TokenConta.Tipo.VERIFICACAO_EMAIL);
        usuario.setEmailVerificado(true);
    }

    @Transactional
    public String solicitarRecuperacao(String email) {
        // A mensagem e sempre igual para nao revelar quais enderecos possuem conta.
        usuarios.findByEmailIgnoreCase(email.trim()).filter(Usuario::isAtivo).ifPresent(usuario -> {
            TokenService.TokenEmitido token = tokens.criarTokenConta(usuario, TokenConta.Tipo.RECUPERACAO_SENHA);
            notificacoes.enviarRecuperacao(usuario.getEmail(), token.valor());
        });
        return "Se o e-mail estiver cadastrado, as instrucoes serao enviadas.";
    }

    @Transactional
    public void redefinirSenha(String token, String novaSenha) {
        validarSenha(novaSenha);
        Usuario usuario = tokens.consumirTokenConta(token, TokenConta.Tipo.RECUPERACAO_SENHA);
        usuario.setSenha(passwordEncoder.encode(novaSenha));
        // Trocar a senha encerra todas as sessoes para cortar acesso de um token possivelmente roubado.
        tokens.encerrarTodas(usuario);
    }

    private void validarSenha(String senha) {
        if (!senha.matches(".*[A-Za-z].*") || !senha.matches(".*\\d.*")) {
            throw new AppException(HttpStatus.BAD_REQUEST, "A senha deve conter letras e numeros.");
        }
    }

    private String normalizarCodigo(String valor) {
        String codigo = Normalizer.normalize(valor, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").replaceAll("[^A-Za-z0-9_-]", "-")
                .replaceAll("-+", "-").replaceAll("^-|-$", "")
                .toUpperCase(Locale.ROOT);
        if (codigo.isBlank()) {
            throw new AppException(HttpStatus.BAD_REQUEST,
                    "O nome da instituicao deve conter ao menos uma letra ou numero.");
        }
        // O banco reserva 40 caracteres para este identificador interno.
        return codigo.substring(0, Math.min(codigo.length(), 40)).replaceAll("-$", "");
    }

    private AppException credenciaisInvalidas() {
        return new AppException(HttpStatus.UNAUTHORIZED, "E-mail ou senha invalidos.");
    }
}
