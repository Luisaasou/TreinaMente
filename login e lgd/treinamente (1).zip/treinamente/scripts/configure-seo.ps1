param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^https://')]
    [string]$SiteUrl,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^https://')]
    [string]$ApiUrl
)

# Resolve a pasta pelo local do script para funcionar mesmo quando chamado de outro diretorio.
$frontendPath = Resolve-Path (Join-Path $PSScriptRoot '..\frontend')
$siteBase = $SiteUrl.TrimEnd('/')
$apiBase = $ApiUrl.TrimEnd('/')
$indexPath = Join-Path $frontendPath 'index.html'
$index = Get-Content -Raw -LiteralPath $indexPath
# A API fica em meta tag para permitir configurar o mesmo frontend sem recompilar JavaScript.
$index = $index -replace '<meta name="api-base" content="[^"]+">', "<meta name=`"api-base`" content=`"$apiBase/api`">"
Set-Content -LiteralPath $indexPath -Value $index -Encoding utf8

# Sitemap so e gerado quando existe um dominio HTTPS real; localhost nao deve ir aos buscadores.
$sitemap = @"
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>$siteBase/</loc>
  </url>
</urlset>
"@
Set-Content -LiteralPath (Join-Path $frontendPath 'sitemap.xml') -Value $sitemap -Encoding utf8

# robots.txt aponta para o sitemap da mesma origem e evita URL canonica divergente.
$robots = @"
User-agent: *
Allow: /

Sitemap: $siteBase/sitemap.xml
"@
Set-Content -LiteralPath (Join-Path $frontendPath 'robots.txt') -Value $robots -Encoding utf8

Write-Host "SEO configurado para $siteBase e API $apiBase."
