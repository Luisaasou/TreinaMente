# Implementacao SEO do TreinaMente

Este registro separa o que esta implementado no codigo do que depende de dominio, publicacao ou credenciais externas.

## Implementado

- HTML em `pt-BR`, hierarquia de titulos, landmarks, link de salto e controles nativos acessiveis.
- Titulo, descricao, robots, Open Graph, tema e manifesto da aplicacao.
- Canonical e `og:url` calculados com a origem real em tempo de execucao.
- JSON-LD `WebApplication` com URL da origem publicada.
- Conteudo inicial claro sobre produto, publico, fluxo e limite de saude.
- Layout responsivo e suporte a `prefers-reduced-motion`.
- Ilustracao principal feita em CSS e texto sem arquivo pesado, imagem sem alt ou risco de CLS.
- `robots.txt` permissivo para mecanismos de busca e crawlers de citacao.
- Gerador de `sitemap.xml`, `robots.txt` e endereco da API com URLs HTTPS reais no deploy.
- Respostas de integracoes externas nunca sao inventadas quando chaves estao ausentes.
- Fluxo de autenticacao com URLs publicas separadas das areas privadas, evitando indexar dados de alunos.

## Nao se aplica ao escopo atual

- Hreflang: existe somente uma versao em portugues do Brasil.
- SEO local e mapas: o TreinaMente e uma plataforma educacional, nao um estabelecimento local ou negocio com area de atendimento.
- Otimizacao de imagens raster: a pagina atual nao publica fotografias ou banners rasterizados.
- Schema de FAQ: nao foi adicionado; o projeto nao depende de resultado rico de FAQ.

## Depende do deploy ou de conta externa

- Gerar sitemap final: executar `scripts/configure-seo.ps1` com o dominio e a API publicados.
- Google Search Console, CrUX, PageSpeed e GA4: configurar a propriedade e credenciais depois do deploy.
- Bing Webmaster e IndexNow: cadastrar o dominio e criar a chave no host antes de enviar URLs.
- Ahrefs, Profound e analise de backlinks: exigem contas e dados ao vivo; nao ha metricas simuladas no repositorio.
- Drift: capturar a primeira linha de base somente depois que a URL de producao estiver estavel.
- Auditoria de citacoes por IA: medir ChatGPT, Perplexity e mecanismos similares com consultas e dominio reais.
- Cluster de conteudo: definir palavras-chave e calendario editorial com o curso antes de criar novas paginas publicas.

## Gate de publicacao

1. Executar o gerador SEO com URLs HTTPS reais.
2. Confirmar que `robots.txt` aponta para o sitemap absoluto.
3. Validar o JSON-LD e o sitemap.
4. Executar Lighthouse em mobile e desktop.
5. Cadastrar o dominio no Google Search Console e Bing Webmaster Tools.
6. Criar uma linha de base de SEO para detectar regressao apos cada deploy.
