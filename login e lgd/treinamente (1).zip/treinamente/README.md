# TreinaMente

Plataforma web educacional para estudantes e professores de Educacao Fisica. O projeto implementa cadastro por perfil, instituicoes, aulas, matricula de alunos, conteudo atualizado pelo professor, comunicacao da turma, painel, apoio educacional por Gemini e pesquisa Google.

## Tecnologias

- Backend: Java 17+, Spring Boot, Spring Security, Spring Data JPA e MySQL
- Frontend: HTML semantico, CSS responsivo e JavaScript
- Seguranca: BCrypt, sessoes opacas armazenadas como hash, autorizacao por perfil e instituicao

## Funcionalidades

- Cadastro e login de estudantes e professores
- Criacao opcional do primeiro administrador por variaveis de ambiente
- Confirmacao de e-mail e recuperacao de senha por SMTP
- Vinculo de usuarios a uma instituicao
- Criacao de aulas pelo professor
- Matricula de alunos da mesma instituicao
- Publicacao e atualizacao do conteudo da aula
- Acompanhamento do conteudo pelo aluno com atualizacao periodica
- Conversa entre professor e estudantes no contexto da aula
- Painel resumido para professor e administrador
- Tutor Gemini com limites para temas de dor, lesao e diagnostico
- Pesquisa Google Custom Search com SafeSearch
- Base de SEO: metadados, dados estruturados, robots, gerador de sitemap e HTML acessivel
- Auditoria: log automatico de todo acesso autenticado (rota, metodo, status, IP) mais eventos explicitos de
  login, logout, cadastro e aceite de LGPD; consulta pelo administrador (todos os registros) ou por qualquer
  usuario (proprio historico)
- LGPD: Termo de Uso e Politica de Privacidade versionados, especificos do projeto, acessiveis a qualquer
  momento (mesmo sem login); aceite obrigatorio e separado por finalidade no cadastro, com historico de
  consentimento consultavel pelo proprio titular

## 1 Banco de dados

Para uma instalacao nova, execute [database/script.sql](database/script.sql) no MySQL 8.

Se o banco veio da primeira versao do MVP, execute uma unica vez, na ordem:

1. `database/migrations/V2__plataforma_academica.sql`
2. `database/migrations/V3__auditoria_lgpd.sql`
3. `database/script.sql`

Em desenvolvimento, o Hibernate usa `ddl-auto=update`, mas o script continua sendo a referencia para ambientes controlados.

## 2 Configuracao

Copie as chaves de [.env.example](.env.example) para variaveis de ambiente do sistema ou da configuracao de execucao da IDE. Nao grave valores reais no repositorio.

Minimo para iniciar:

```text
DB_USERNAME=root
DB_PASSWORD=sua-senha
APP_CORS_ALLOWED_ORIGINS=http://localhost:5500
```

As integracoes Gemini, Google Search e SMTP sao opcionais. Quando uma delas nao esta configurada, o backend responde `503` com uma mensagem explicita em vez de fabricar resultados.

Para criar o primeiro administrador, defina `ADMIN_EMAIL` e `ADMIN_PASSWORD` antes da primeira inicializacao. A senha precisa ter pelo menos 12 caracteres e nunca e registrada nos logs.

## 3 Executar o backend

No IntelliJ IDEA, abra a pasta `backend` como projeto Maven e execute `TreinaMenteApplication`.

Pelo terminal, use o Maven instalado no ambiente:

```powershell
cd backend
mvn spring-boot:run
```

O backend inicia em `http://localhost:8080`.

## 4 Executar o frontend

Sirva a pasta `frontend` por HTTP. Nao abra o arquivo diretamente, pois manifest, robots e chamadas de rede dependem de uma origem web.

Exemplo com a extensao Live Server do VS Code: publique `frontend` em `http://localhost:5500`.

## 5 Preparar SEO para deploy

Como o dominio publico ainda nao esta definido no projeto, o sitemap nao deve conter um endereco inventado. No deploy, gere os arquivos com os enderecos reais:

```powershell
.\scripts\configure-seo.ps1 -SiteUrl "https://seu-dominio.com.br" -ApiUrl "https://api.seu-dominio.com.br"
```

O comando atualiza a origem da API e cria `frontend/sitemap.xml` e `frontend/robots.txt` com URLs absolutas. Depois valide o sitemap e cadastre a propriedade nos mecanismos de busca.

## Endpoints principais

| Metodo | Caminho | Perfil |
|---|---|---|
| POST | `/api/auth/registro` | Publico (exige `aceiteTermoUso` e `aceitePoliticaPrivacidade` = `true`) |
| POST | `/api/auth/login` | Publico |
| POST | `/api/auth/verificar-email` | Publico |
| POST | `/api/auth/recuperar-senha` | Publico |
| GET/POST | `/api/aulas` | Autenticado / professor |
| PUT | `/api/aulas/{id}/conteudo` | Professor dono ou admin |
| POST | `/api/aulas/{id}/alunos` | Professor dono ou admin |
| GET/POST | `/api/aulas/{id}/mensagens` | Participante da aula |
| POST | `/api/ia/perguntar` | Autenticado |
| GET | `/api/pesquisas?q=...` | Autenticado |
| GET | `/api/dashboard` | Professor ou admin |
| GET | `/api/legal/termo-uso` | Publico |
| GET | `/api/legal/politica-privacidade` | Publico |
| POST | `/api/legal/aceite` | Autenticado |
| GET | `/api/legal/meus-aceites` | Autenticado |
| GET | `/api/auditoria?pagina=0&tamanho=50` | Admin |
| GET | `/api/auditoria/minhas?pagina=0&tamanho=50` | Autenticado |

## Privacidade e limites

O sistema nao solicita localizacao nem dados clinicos. Evite inserir informacoes de saude identificaveis no chat ou no tutor. A IA e uma ferramenta de apoio academico e nao substitui avaliacao medica, fisioterapeutica ou de outro profissional habilitado.
