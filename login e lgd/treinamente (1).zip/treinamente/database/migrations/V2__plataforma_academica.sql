-- Execute apenas em bancos criados pela versao inicial do projeto.
-- A migracao preserva os cadastros existentes e acrescenta os campos antes das novas tabelas.
CREATE TABLE IF NOT EXISTS instituicoes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(160) NOT NULL,
    codigo VARCHAR(40) NOT NULL UNIQUE,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE cadastro
    MODIFY id BIGINT AUTO_INCREMENT,
    MODIFY email VARCHAR(160) NOT NULL,
    ADD COLUMN perfil VARCHAR(20) NOT NULL DEFAULT 'ALUNO',
    ADD COLUMN ativo BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN email_verificado BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN instituicao_id BIGINT NULL,
    ADD COLUMN criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ADD COLUMN atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    ADD CONSTRAINT fk_cadastro_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicoes(id);

-- Depois desta migracao, execute database/script.sql para criar as demais tabelas.
