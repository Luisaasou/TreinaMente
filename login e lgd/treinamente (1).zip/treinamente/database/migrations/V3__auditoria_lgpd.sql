-- Execute apenas em bancos ja criados pela V2 (ou pelo script.sql anterior a esta versao).
-- Acrescenta a trilha de auditoria e o historico de aceite de LGPD sem tocar nas tabelas existentes.

CREATE TABLE IF NOT EXISTS consentimentos_lgpd (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT NOT NULL,
    tipo VARCHAR(30) NOT NULL,
    versao_documento VARCHAR(20) NOT NULL,
    aceito_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip VARCHAR(64),
    CONSTRAINT fk_consentimento_usuario FOREIGN KEY (usuario_id) REFERENCES cadastro(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS logs_auditoria (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT NULL,
    usuario_email VARCHAR(160),
    acao VARCHAR(60) NOT NULL,
    detalhe VARCHAR(500),
    metodo VARCHAR(10),
    recurso VARCHAR(255),
    status_http INT,
    ip VARCHAR(64),
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_consentimentos_usuario ON consentimentos_lgpd(usuario_id);
CREATE INDEX idx_logs_auditoria_usuario ON logs_auditoria(usuario_id);
CREATE INDEX idx_logs_auditoria_criado ON logs_auditoria(criado_em);
