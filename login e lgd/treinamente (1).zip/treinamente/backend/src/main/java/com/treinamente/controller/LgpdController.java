package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.model.Usuario;
import com.treinamente.service.LgpdService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/legal")
// Os documentos ficam acessiveis publicamente (mesmo sem login); o aceite e o historico exigem sessao.
public class LgpdController {
    private final LgpdService lgpd;
    public LgpdController(LgpdService lgpd) { this.lgpd = lgpd; }

    @GetMapping("/termo-uso")
    public TermoResponse termoUso() { return lgpd.termoUso(); }

    @GetMapping("/politica-privacidade")
    public TermoResponse politicaPrivacidade() { return lgpd.politicaPrivacidade(); }

    @PostMapping("/aceite")
    public ConsentimentoResponse aceitar(@Valid @RequestBody AceiteLgpdRequest request,
                                          @AuthenticationPrincipal Usuario usuario) {
        return lgpd.registrarAceite(usuario, request.tipo());
    }

    @GetMapping("/meus-aceites")
    public List<ConsentimentoResponse> meusAceites(@AuthenticationPrincipal Usuario usuario) {
        return lgpd.meusConsentimentos(usuario);
    }
}
