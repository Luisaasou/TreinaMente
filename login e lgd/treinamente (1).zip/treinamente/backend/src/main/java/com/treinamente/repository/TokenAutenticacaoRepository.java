package com.treinamente.repository;

import com.treinamente.model.TokenAutenticacao;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.Optional;

// Busca e revogacao usam apenas o hash para que o segredo bruto nao seja persistido.
public interface TokenAutenticacaoRepository extends JpaRepository<TokenAutenticacao, Long> {
    Optional<TokenAutenticacao> findByTokenHashAndExpiraEmAfter(String tokenHash, Instant agora);
    void deleteByTokenHash(String tokenHash);
    void deleteByUsuarioId(Long usuarioId);
    void deleteByExpiraEmBefore(Instant agora);
}
