package com.treinamente.service;

import com.treinamente.model.LogAuditoria;
import com.treinamente.model.Usuario;
import com.treinamente.repository.LogAuditoriaRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Service
// Centraliza a trilha de auditoria: toda gravacao roda em transacao propria (REQUIRES_NEW) para que
// o registro sobreviva mesmo se a operacao de negocio que o originou vier a falhar e sofrer rollback.
public class AuditoriaService {
    private final LogAuditoriaRepository logs;

    public AuditoriaService(LogAuditoriaRepository logs) { this.logs = logs; }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void registrar(Usuario usuario, String acao, String detalhe) {
        gravar(usuario, acao, detalhe, null, null, null);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void registrarAcesso(Usuario usuario, String metodo, String recurso, int status) {
        gravar(usuario, "ACESSO", null, metodo, recurso, status);
    }

    private void gravar(Usuario usuario, String acao, String detalhe, String metodo, String recurso, Integer status) {
        LogAuditoria log = new LogAuditoria();
        log.setUsuarioId(usuario == null ? null : usuario.getId());
        log.setUsuarioEmail(usuario == null ? "anonimo" : usuario.getEmail());
        log.setAcao(acao);
        log.setDetalhe(detalhe);
        log.setMetodo(metodo);
        log.setRecurso(recurso);
        log.setStatusHttp(status);
        log.setIp(enderecoRemotoAtual());
        // Uma falha ao gravar auditoria nunca deve derrubar a operacao original do usuario.
        try {
            logs.save(log);
        } catch (RuntimeException ignored) {
            // Intencionalmente silencioso: auditoria e complementar, nao pode ser causa de indisponibilidade.
        }
    }

    private String enderecoRemotoAtual() {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attrs == null) return null;
        HttpServletRequest request = attrs.getRequest();
        String encaminhado = request.getHeader("X-Forwarded-For");
        // Atras de um proxy, o primeiro endereco da lista e o cliente original.
        return (encaminhado != null && !encaminhado.isBlank()) ? encaminhado.split(",")[0].trim() : request.getRemoteAddr();
    }

    @Transactional(readOnly = true)
    public Page<LogAuditoria> listarTodos(Pageable pageable) { return logs.findAllByOrderByCriadoEmDesc(pageable); }

    @Transactional(readOnly = true)
    public Page<LogAuditoria> listarPorUsuario(Long usuarioId, Pageable pageable) {
        return logs.findByUsuarioIdOrderByCriadoEmDesc(usuarioId, pageable);
    }
}
