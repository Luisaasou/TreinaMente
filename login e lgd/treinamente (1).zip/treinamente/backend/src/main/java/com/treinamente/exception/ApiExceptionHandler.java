package com.treinamente.exception;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.Map;
import java.util.stream.Collectors;

@RestControllerAdvice
// Traduz falhas esperadas para um formato unico, sem devolver rastros internos ao navegador.
public class ApiExceptionHandler {
    @ExceptionHandler(AppException.class)
    ResponseEntity<Map<String, Object>> app(AppException exception) {
        return resposta(exception.getStatus(), exception.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<Map<String, Object>> validacao(MethodArgumentNotValidException exception) {
        String detalhes = exception.getBindingResult().getFieldErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .distinct().collect(Collectors.joining("; "));
        return resposta(HttpStatus.BAD_REQUEST, "Dados invalidos: " + detalhes);
    }

    @ExceptionHandler(AccessDeniedException.class)
    ResponseEntity<Map<String, Object>> acessoNegado(AccessDeniedException exception) {
        return resposta(HttpStatus.FORBIDDEN, "Voce nao tem permissao para esta operacao.");
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<Map<String, Object>> inesperado(Exception exception) {
        return resposta(HttpStatus.INTERNAL_SERVER_ERROR, "Nao foi possivel concluir a operacao.");
    }

    private ResponseEntity<Map<String, Object>> resposta(HttpStatus status, String mensagem) {
        // Um formato unico simplifica o tratamento de erro em todas as telas.
        return ResponseEntity.status(status).body(Map.of(
                "status", status.value(), "mensagem", mensagem, "instante", Instant.now().toString()));
    }
}
