package com.treinamente.repository;

import com.treinamente.model.Usuario;
import com.treinamente.model.Perfil;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

// E-mail sem diferenca de maiusculas evita contas duplicadas por variacao de digitacao.
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    Optional<Usuario> findByEmailIgnoreCase(String email);
    List<Usuario> findByInstituicaoIdAndPerfil(Long instituicaoId, Perfil perfil);
    long countByPerfil(Perfil perfil);
}
