package com.treinamente.model;

// Perfis fechados facilitam conferir as barreiras de aluno, professor e administrador.
public enum Perfil {
    ADMIN,
    PROFESSOR,
    ALUNO
}
