package com.treinamente.exception;

import org.springframework.http.HttpStatus;

// Leva o status HTTP junto da regra de negocio sem acoplar os servicos ao formato da resposta JSON.
public class AppException extends RuntimeException {
    private final HttpStatus status;

    public AppException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() { return status; }
}
