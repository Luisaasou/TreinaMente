package com.treinamente.repository;

import com.treinamente.model.Aula;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

// Consultas daqui ja limitam os dados ao vinculo do usuario antes de montar a tela de aulas.
public interface AulaRepository extends JpaRepository<Aula, Long> {
    @EntityGraph(attributePaths = {"professor", "instituicao", "alunos"})
    List<Aula> findDistinctByProfessorIdOrAlunosIdOrderByAtualizadaEmDesc(Long professorId, Long alunoId);

    @EntityGraph(attributePaths = {"professor", "instituicao", "alunos"})
    Optional<Aula> findById(Long id);

    long countByProfessorId(Long professorId);
}
