package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.model.Usuario;
import com.treinamente.service.*;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
// Mantem as rotas de identidade finas; validacao e regras de conta ficam nos servicos.
public class AuthController {
    private final AuthService auth;
    private final TokenService tokens;
    private final AuditoriaService auditoria;
    public AuthController(AuthService auth, TokenService tokens, AuditoriaService auditoria) {
        this.auth = auth; this.tokens = tokens; this.auditoria = auditoria;
    }

    @PostMapping("/registro")
    public ResponseEntity<RegistroResponse> registrar(@Valid @RequestBody RegistroRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(auth.registrar(request));
    }
    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest request) { return auth.login(request); }
    @GetMapping("/me")
    public UsuarioResponse me(@AuthenticationPrincipal Usuario usuario) { return UsuarioResponse.from(usuario); }
    @PostMapping("/logout")
    public MensagemResponse logout(@RequestHeader(value = "Authorization", required = false) String header) {
        // Logout continua idempotente mesmo quando o navegador ja perdeu o token.
        if (header != null && header.startsWith("Bearer ")) {
            String valor = header.substring(7);
            Usuario usuario = tokens.autenticar(valor);
            tokens.encerrar(valor);
            if (usuario != null) auditoria.registrar(usuario, "LOGOUT", "Sessao encerrada pelo usuario.");
        }
        return new MensagemResponse("Sessao encerrada.");
    }
    @PostMapping("/verificar-email")
    public MensagemResponse verificar(@Valid @RequestBody TokenRequest request) {
        auth.verificarEmail(request.token()); return new MensagemResponse("E-mail confirmado.");
    }
    @PostMapping("/recuperar-senha")
    public MensagemResponse recuperar(@Valid @RequestBody RecuperarSenhaRequest request) {
        return new MensagemResponse(auth.solicitarRecuperacao(request.email()));
    }
    @PostMapping("/redefinir-senha")
    public MensagemResponse redefinir(@Valid @RequestBody RedefinirSenhaRequest request) {
        auth.redefinirSenha(request.token(), request.novaSenha());
        return new MensagemResponse("Senha redefinida.");
    }
}
