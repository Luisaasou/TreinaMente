package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.model.Usuario;
import com.treinamente.service.AuditoriaService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auditoria")
// Consulta a trilha de auditoria: o administrador enxerga tudo, os demais perfis so o proprio historico.
public class AuditoriaController {
    private final AuditoriaService auditoria;
    public AuditoriaController(AuditoriaService auditoria) { this.auditoria = auditoria; }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Page<LogAuditoriaResponse> listarTodos(@RequestParam(defaultValue = "0") int pagina,
                                                   @RequestParam(defaultValue = "50") int tamanho) {
        return auditoria.listarTodos(paginaSegura(pagina, tamanho)).map(LogAuditoriaResponse::from);
    }

    @GetMapping("/minhas")
    public Page<LogAuditoriaResponse> minhas(@AuthenticationPrincipal Usuario usuario,
                                              @RequestParam(defaultValue = "0") int pagina,
                                              @RequestParam(defaultValue = "50") int tamanho) {
        return auditoria.listarPorUsuario(usuario.getId(), paginaSegura(pagina, tamanho)).map(LogAuditoriaResponse::from);
    }

    private PageRequest paginaSegura(int pagina, int tamanho) {
        // Limita o tamanho de pagina para impedir uma consulta acidentalmente enorme.
        return PageRequest.of(Math.max(pagina, 0), Math.min(Math.max(tamanho, 1), 200));
    }
}
