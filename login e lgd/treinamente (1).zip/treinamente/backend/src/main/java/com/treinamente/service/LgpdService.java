package com.treinamente.service;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.model.ConsentimentoLgpd;
import com.treinamente.model.Usuario;
import com.treinamente.repository.ConsentimentoLgpdRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import java.time.Instant;
import java.util.List;

@Service
// Concentra os textos legais do TreinaMente e o registro de aceite, para que ambos evoluam juntos e
// versionados: mudar o conteudo sem subir a versao invalidaria o historico de consentimento.
public class LgpdService {
    private static final String VERSAO_TERMO = "1.0";
    private static final String VERSAO_POLITICA = "1.0";
    private static final Instant ATUALIZADO_EM = Instant.parse("2026-09-01T00:00:00Z");

    private static final String TERMO_USO = String.join("\n\n",
            "1. Sobre o TreinaMente. O TreinaMente e uma plataforma educacional para a formacao em "
                    + "Educacao Fisica, usada por estudantes, professores e administradores de instituicoes de "
                    + "ensino cadastradas, com o objetivo de organizar aulas, comunicacao entre professor e aluno "
                    + "e apoio ao estudo por inteligencia artificial.",
            "2. Cadastro e responsabilidade pela conta. Ao criar uma conta, voce declara que as informacoes "
                    + "fornecidas (nome, e-mail, instituicao e perfil) sao verdadeiras. A senha e de uso pessoal e "
                    + "intransferivel; voce e responsavel por manter sua confidencialidade e por qualquer atividade "
                    + "realizada com suas credenciais.",
            "3. Uso aceitavel. As funcionalidades da plataforma devem ser usadas para fins educacionais. Nao e "
                    + "permitido enviar mensagens ofensivas, tentar acessar aulas ou dados de outras instituicoes, "
                    + "burlar os controles de autenticacao e autorizacao, nem usar a integracao de inteligencia "
                    + "artificial para obter diagnostico medico, prescricao de tratamento ou qualquer orientacao "
                    + "clinica: o conteudo gerado e exclusivamente educacional.",
            "4. Perfis de acesso. O perfil ALUNO participa de aulas nas quais foi matriculado por um professor da "
                    + "mesma instituicao. O perfil PROFESSOR cria aulas, publica conteudo e matricula estudantes da "
                    + "propria instituicao. O perfil ADMIN e criado apenas pela administracao do sistema e tem "
                    + "acesso amplo para fins de suporte, seguranca e auditoria.",
            "5. Disponibilidade. O TreinaMente e um projeto de formacao academica (Projeto Final de Curso) e pode "
                    + "passar por manutencoes, instabilidades e mudancas sem aviso previo. Nenhuma disponibilidade "
                    + "continua e garantida.",
            "6. Suspensao e encerramento. Contas usadas em desacordo com este Termo podem ser suspensas ou "
                    + "encerradas. O usuario pode solicitar a exclusao da propria conta a qualquer momento pelos "
                    + "canais de contato informados na Politica de Privacidade.",
            "7. Alteracoes deste Termo. Alteracoes relevantes neste Termo geram uma nova versao e um novo aceite "
                    + "sera solicitado antes que voce continue usando a plataforma.",
            "Versao " + VERSAO_TERMO + ", vigente desde 01/09/2026.");

    private static final String POLITICA_PRIVACIDADE = String.join("\n\n",
            "1. Controlador dos dados. O TreinaMente, projeto academico de Educacao Fisica, e o controlador dos "
                    + "dados pessoais tratados nesta plataforma. Duvidas sobre este documento ou sobre seus dados "
                    + "podem ser enviadas ao encarregado pelo tratamento em privacidade@treinamente.exemplo.",
            "2. Dados pessoais coletados. Coletamos: (a) dados de cadastro - nome, e-mail, senha (armazenada apenas "
                    + "como hash criptografico, nunca em texto legivel), perfil (aluno, professor ou administrador) e "
                    + "instituicao de ensino; (b) dados de uso academico - aulas criadas ou cursadas, conteudo "
                    + "publicado pelo professor, mensagens trocadas no chat de cada aula e perguntas enviadas ao "
                    + "apoio educacional por inteligencia artificial; (c) dados tecnicos de seguranca - endereco IP, "
                    + "data e hora de acesso, metodo e rota chamada na API, para fins de auditoria e prevencao a "
                    + "fraude.",
            "3. Finalidades do tratamento. Os dados sao usados para: autenticar e autorizar o acesso conforme o "
                    + "perfil do usuario; viabilizar a comunicacao e o conteudo das aulas entre professor e aluno da "
                    + "mesma instituicao; gerar respostas do apoio educacional por IA e resultados de pesquisa "
                    + "externa quando solicitados; manter registros de auditoria de acessos e acoes para seguranca "
                    + "da plataforma; e cumprir obrigacoes legais e regulatorias aplicaveis.",
            "4. Base legal. O tratamento ocorre com base na execucao de um contrato ou de procedimentos "
                    + "preliminares solicitados pelo titular (Art. 7, V, LGPD), no consentimento livre e informado "
                    + "obtido no cadastro (Art. 7, I, LGPD) e no legitimo interesse do controlador em manter a "
                    + "seguranca do sistema (Art. 7, IX, LGPD).",
            "5. Compartilhamento com terceiros. Perguntas enviadas ao apoio educacional sao repassadas somente ao "
                    + "provedor de IA (Google Gemini) e termos de pesquisa somente ao provedor de busca (Google "
                    + "Custom Search), exclusivamente para processar aquela solicitacao pontual. O TreinaMente nao "
                    + "vende nem compartilha dados pessoais com terceiros para fins de publicidade.",
            "6. Retencao e eliminacao. Os dados de cadastro e de uso academico sao mantidos enquanto a conta "
                    + "estiver ativa e pelo prazo adicional necessario para cumprir obrigacao legal ou defesa em "
                    + "processos; os registros de auditoria sao mantidos pelo prazo necessario para fins de "
                    + "seguranca. Apos esses prazos, os dados sao eliminados ou anonimizados.",
            "7. Direitos do titular. Nos termos do Art. 18 da LGPD, voce pode solicitar, a qualquer momento: "
                    + "confirmacao da existencia de tratamento; acesso aos dados; correcao de dados incompletos, "
                    + "inexatos ou desatualizados; anonimizacao, bloqueio ou eliminacao de dados desnecessarios; "
                    + "portabilidade dos dados; eliminacao dos dados tratados com base no consentimento; informacao "
                    + "sobre entidades com quem os dados foram compartilhados; e revogacao do consentimento. As "
                    + "solicitacoes podem ser feitas pelo canal indicado no item 1.",
            "8. Seguranca. Senhas sao protegidas com hash BCrypt, sessoes usam tokens opacos com validade limitada "
                    + "e toda a comunicacao com a API deve ocorrer por HTTPS em producao. O acesso as funcionalidades "
                    + "e restrito por perfil e por instituicao.",
            "9. Alteracoes desta Politica. Alteracoes relevantes geram uma nova versao e um novo aceite sera "
                    + "solicitado antes que voce continue usando a plataforma.",
            "Versao " + VERSAO_POLITICA + ", vigente desde 01/09/2026.");

    private final ConsentimentoLgpdRepository consentimentos;
    private final AuditoriaService auditoria;

    public LgpdService(ConsentimentoLgpdRepository consentimentos, AuditoriaService auditoria) {
        this.consentimentos = consentimentos;
        this.auditoria = auditoria;
    }

    public TermoResponse termoUso() {
        return new TermoResponse("Termo de Uso", VERSAO_TERMO, ATUALIZADO_EM, TERMO_USO);
    }

    public TermoResponse politicaPrivacidade() {
        return new TermoResponse("Politica de Privacidade", VERSAO_POLITICA, ATUALIZADO_EM, POLITICA_PRIVACIDADE);
    }

    @Transactional
    public ConsentimentoResponse registrarAceite(Usuario usuario, ConsentimentoLgpd.Tipo tipo) {
        ConsentimentoLgpd consentimento = new ConsentimentoLgpd();
        consentimento.setUsuario(usuario);
        consentimento.setTipo(tipo);
        consentimento.setVersaoDocumento(tipo == ConsentimentoLgpd.Tipo.TERMO_USO ? VERSAO_TERMO : VERSAO_POLITICA);
        consentimento.setIp(enderecoRemotoAtual());
        consentimentos.save(consentimento);
        auditoria.registrar(usuario, "ACEITE_LGPD",
                "Aceite de " + tipo.name() + " versao " + consentimento.getVersaoDocumento());
        return ConsentimentoResponse.from(consentimento);
    }

    @Transactional(readOnly = true)
    public List<ConsentimentoResponse> meusConsentimentos(Usuario usuario) {
        return consentimentos.findByUsuarioIdOrderByAceitoEmDesc(usuario.getId())
                .stream().map(ConsentimentoResponse::from).toList();
    }

    private String enderecoRemotoAtual() {
        ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attrs == null) return null;
        HttpServletRequest request = attrs.getRequest();
        String encaminhado = request.getHeader("X-Forwarded-For");
        return (encaminhado != null && !encaminhado.isBlank()) ? encaminhado.split(",")[0].trim() : request.getRemoteAddr();
    }
}
