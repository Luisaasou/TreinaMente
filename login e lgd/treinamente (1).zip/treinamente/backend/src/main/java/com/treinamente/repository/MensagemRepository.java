package com.treinamente.repository;

import com.treinamente.model.Mensagem;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

// A ordem cronologica e o limite mantem a conversa consistente e leve para o cliente.
public interface MensagemRepository extends JpaRepository<Mensagem, Long> {
    @EntityGraph(attributePaths = {"autor"})
    List<Mensagem> findTop100ByAulaIdOrderByCriadaEmAsc(Long aulaId);
    long countByAulaProfessorId(Long professorId);
}
