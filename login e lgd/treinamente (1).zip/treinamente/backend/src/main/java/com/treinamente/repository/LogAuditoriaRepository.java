package com.treinamente.repository;

import com.treinamente.model.LogAuditoria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

// A ordenacao por data desce do mais recente porque a auditoria e consultada de tras para frente.
public interface LogAuditoriaRepository extends JpaRepository<LogAuditoria, Long> {
    Page<LogAuditoria> findAllByOrderByCriadoEmDesc(Pageable pageable);
    Page<LogAuditoria> findByUsuarioIdOrderByCriadoEmDesc(Long usuarioId, Pageable pageable);
    Page<LogAuditoria> findByAcaoOrderByCriadoEmDesc(String acao, Pageable pageable);
}
