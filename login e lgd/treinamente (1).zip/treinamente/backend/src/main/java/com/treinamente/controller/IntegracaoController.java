package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.service.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@Validated
// Reune integracoes externas para que credenciais e tratamento de falhas nao cheguem ao navegador.
public class IntegracaoController {
    private final IaEducacionalService ia;
    private final PesquisaGoogleService pesquisa;
    public IntegracaoController(IaEducacionalService ia, PesquisaGoogleService pesquisa) {
        this.ia = ia; this.pesquisa = pesquisa;
    }
    @PostMapping("/ia/perguntar")
    public RespostaIaResponse perguntar(@Valid @RequestBody PerguntaIaRequest request) {
        return ia.perguntar(request.pergunta());
    }
    @GetMapping("/pesquisas")
    public PesquisaResponse pesquisar(@RequestParam("q") @Size(min = 3, max = 200) String consulta) {
        return pesquisa.pesquisar(consulta.trim());
    }
}
