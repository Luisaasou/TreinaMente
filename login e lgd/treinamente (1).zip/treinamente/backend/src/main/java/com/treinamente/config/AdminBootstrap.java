package com.treinamente.config;

import com.treinamente.model.*;
import com.treinamente.repository.*;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
// Cria o primeiro administrador somente quando as credenciais vierem do ambiente e a conta ainda nao existir.
public class AdminBootstrap implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(AdminBootstrap.class);
    private final UsuarioRepository usuarios;
    private final InstituicaoRepository instituicoes;
    private final PasswordEncoder encoder;
    private final String email;
    private final String senha;

    public AdminBootstrap(UsuarioRepository usuarios, InstituicaoRepository instituicoes, PasswordEncoder encoder,
                          @Value("${ADMIN_EMAIL:}") String email, @Value("${ADMIN_PASSWORD:}") String senha) {
        this.usuarios = usuarios; this.instituicoes = instituicoes; this.encoder = encoder;
        this.email = email; this.senha = senha;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        // Nao usamos senha padrao: sem configuracao explicita, o bootstrap simplesmente nao faz nada.
        if (email.isBlank() || senha.isBlank() || usuarios.findByEmailIgnoreCase(email).isPresent()) return;
        if (senha.length() < 12) {
            log.warn("ADMIN_PASSWORD ignorada: use ao menos 12 caracteres.");
            return;
        }
        Instituicao instituicao = instituicoes.findByCodigoIgnoreCase("ADMIN").orElseGet(() -> {
            // A instituicao tecnica separa o administrador das instituicoes academicas reais.
            Instituicao item = new Instituicao(); item.setNome("Administracao TreinaMente"); item.setCodigo("ADMIN");
            return instituicoes.save(item);
        });
        Usuario admin = new Usuario();
        admin.setNome("Administrador"); admin.setEmail(email.trim().toLowerCase());
        admin.setSenha(encoder.encode(senha)); admin.setPerfil(Perfil.ADMIN); admin.setEmailVerificado(true);
        admin.setInstituicao(instituicao); usuarios.save(admin);
        log.info("Conta administrativa inicial criada com sucesso.");
    }
}
