package com.treinamente.service;

import org.slf4j.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
// Isola o envio de e-mail para que o fluxo principal continue testavel sem depender do SMTP.
public class NotificacaoService {
    private static final Logger log = LoggerFactory.getLogger(NotificacaoService.class);
    private final JavaMailSender mailSender;
    private final String frontendUrl;

    public NotificacaoService(JavaMailSender mailSender,
                              @Value("${app.frontend-url:http://localhost:5500}") String frontendUrl) {
        this.mailSender = mailSender;
        this.frontendUrl = frontendUrl;
    }

    public void enviarVerificacao(String email, String token) {
        enviar(email, "Confirme sua conta TreinaMente",
                "Confirme seu e-mail em: " + frontendUrl + "/?acao=verificar&token=" + token);
    }

    public void enviarRecuperacao(String email, String token) {
        enviar(email, "Recuperacao de senha TreinaMente",
                "Redefina sua senha em: " + frontendUrl + "/?acao=redefinir&token=" + token);
    }

    private void enviar(String destinatario, String assunto, String corpo) {
        try {
            SimpleMailMessage mensagem = new SimpleMailMessage();
            mensagem.setTo(destinatario);
            mensagem.setSubject(assunto);
            mensagem.setText(corpo);
            mailSender.send(mensagem);
        } catch (RuntimeException exception) {
            // Nao registramos corpo nem token: o log informa a falha sem vazar o link de acesso.
            log.warn("E-mail nao enviado; verifique a configuracao SMTP. Destinatario={}", destinatario);
        }
    }
}
