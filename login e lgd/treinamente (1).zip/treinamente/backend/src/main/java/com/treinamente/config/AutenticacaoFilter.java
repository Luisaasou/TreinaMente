package com.treinamente.config;

import com.treinamente.model.Usuario;
import com.treinamente.service.TokenService;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Component
// Converte o token opaco em identidade do Spring sem criar sessao no servidor web.
public class AutenticacaoFilter extends OncePerRequestFilter {
    private final TokenService tokens;

    public AutenticacaoFilter(TokenService tokens) { this.tokens = tokens; }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        // Um cabecalho ausente ou invalido segue anonimo; as regras de rota decidem se isso e permitido.
        if (header != null && header.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication() == null) {
            Usuario usuario = tokens.autenticar(header.substring(7));
            if (usuario != null) {
                var autoridade = new SimpleGrantedAuthority("ROLE_" + usuario.getPerfil().name());
                SecurityContextHolder.getContext().setAuthentication(
                        new UsernamePasswordAuthenticationToken(usuario, null, List.of(autoridade)));
            }
        }
        chain.doFilter(request, response);
    }
}
