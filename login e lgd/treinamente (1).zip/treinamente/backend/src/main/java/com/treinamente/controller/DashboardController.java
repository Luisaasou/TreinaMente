package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.DashboardResponse;
import com.treinamente.model.Usuario;
import com.treinamente.service.DashboardService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
// O painel compartilha a rota, mas os numeros retornados respeitam o perfil autenticado.
public class DashboardController {
    private final DashboardService dashboard;
    public DashboardController(DashboardService dashboard) { this.dashboard = dashboard; }
    @GetMapping
    @PreAuthorize("hasAnyRole('PROFESSOR','ADMIN')")
    public DashboardResponse obter(@AuthenticationPrincipal Usuario usuario) { return dashboard.doProfessor(usuario); }
}
