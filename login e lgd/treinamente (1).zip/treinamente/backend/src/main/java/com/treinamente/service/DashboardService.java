package com.treinamente.service;

import com.treinamente.dto.ApiDtos.DashboardResponse;
import com.treinamente.model.*;
import com.treinamente.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
// Calcula indicadores no servidor para nao expor listas completas so para montar contadores.
public class DashboardService {
    private final AulaRepository aulas;
    private final UsuarioRepository usuarios;
    private final MensagemRepository mensagens;
    public DashboardService(AulaRepository aulas, UsuarioRepository usuarios, MensagemRepository mensagens) {
        this.aulas = aulas; this.usuarios = usuarios; this.mensagens = mensagens;
    }
    @Transactional(readOnly = true)
    public DashboardResponse doProfessor(Usuario usuario) {
        if (usuario.getPerfil() == Perfil.ADMIN) {
            // Para o administrador, os indicadores representam toda a plataforma.
            return new DashboardResponse(aulas.count(), usuarios.countByPerfil(Perfil.ALUNO), mensagens.count(),
                    usuarios.countByPerfil(Perfil.PROFESSOR));
        }
        // O id -1 evita trazer aulas onde o professor apareceria apenas como aluno.
        long alunos = aulas.findDistinctByProfessorIdOrAlunosIdOrderByAtualizadaEmDesc(usuario.getId(), -1L)
                .stream().flatMap(aula -> aula.getAlunos().stream()).map(Usuario::getId).distinct().count();
        return new DashboardResponse(aulas.countByProfessorId(usuario.getId()), alunos,
                mensagens.countByAulaProfessorId(usuario.getId()), 1);
    }
}
