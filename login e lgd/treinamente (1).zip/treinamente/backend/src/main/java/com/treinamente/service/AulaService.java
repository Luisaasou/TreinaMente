package com.treinamente.service;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.exception.AppException;
import com.treinamente.model.*;
import com.treinamente.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
// Aplica as regras de acesso da aula antes de tocar em conteudo, matriculas ou conversa.
public class AulaService {
    private final AulaRepository aulas;
    private final UsuarioRepository usuarios;
    private final MensagemRepository mensagens;

    public AulaService(AulaRepository aulas, UsuarioRepository usuarios, MensagemRepository mensagens) {
        this.aulas = aulas;
        this.usuarios = usuarios;
        this.mensagens = mensagens;
    }

    @Transactional
    public AulaResponse criar(CriarAulaRequest request, Usuario professor) {
        if (professor.getPerfil() != Perfil.PROFESSOR && professor.getPerfil() != Perfil.ADMIN) {
            throw proibido();
        }
        if (professor.getInstituicao() == null) {
            throw new AppException(HttpStatus.BAD_REQUEST, "Associe o professor a uma instituicao.");
        }
        Aula aula = new Aula();
        aula.setTitulo(request.titulo().trim());
        aula.setDescricao(limpar(request.descricao()));
        aula.setProfessor(professor);
        aula.setInstituicao(professor.getInstituicao());
        return AulaResponse.from(aulas.save(aula));
    }

    @Transactional(readOnly = true)
    public List<AulaResponse> listar(Usuario usuario) {
        // O administrador enxerga o conjunto completo; os demais recebem apenas aulas em que participam.
        List<Aula> resultado = usuario.getPerfil() == Perfil.ADMIN ? aulas.findAll()
                : aulas.findDistinctByProfessorIdOrAlunosIdOrderByAtualizadaEmDesc(usuario.getId(), usuario.getId());
        return resultado.stream().map(AulaResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public AulaResponse detalhe(Long id, Usuario usuario) { return AulaResponse.from(permitida(id, usuario)); }

    @Transactional
    public AulaResponse atualizarConteudo(Long id, AtualizarConteudoRequest request, Usuario usuario) {
        Aula aula = gerenciavel(id, usuario);
        aula.setConteudoAtual(request.conteudo().trim());
        return AulaResponse.from(aula);
    }

    @Transactional
    public AulaResponse matricular(Long id, MatricularAlunoRequest request, Usuario usuario) {
        Aula aula = gerenciavel(id, usuario);
        Usuario aluno = usuarios.findByEmailIgnoreCase(request.email().trim())
                .orElseThrow(() -> new AppException(HttpStatus.NOT_FOUND, "Aluno nao encontrado."));
        if (aluno.getPerfil() != Perfil.ALUNO) {
            throw new AppException(HttpStatus.BAD_REQUEST, "O usuario informado nao possui perfil de aluno.");
        }
        if (aluno.getInstituicao() == null || !aluno.getInstituicao().getId().equals(aula.getInstituicao().getId())) {
            // A barreira por instituicao impede matricula acidental entre organizacoes diferentes.
            throw new AppException(HttpStatus.FORBIDDEN, "Aluno e aula devem pertencer a mesma instituicao.");
        }
        aula.getAlunos().add(aluno);
        return AulaResponse.from(aula);
    }

    @Transactional
    public ChatResponse enviarMensagem(Long aulaId, EnviarMensagemRequest request, Usuario autor) {
        Aula aula = permitida(aulaId, autor);
        Mensagem mensagem = new Mensagem();
        mensagem.setAula(aula);
        mensagem.setAutor(autor);
        mensagem.setTexto(request.texto().trim());
        return ChatResponse.from(mensagens.save(mensagem));
    }

    @Transactional(readOnly = true)
    public List<ChatResponse> listarMensagens(Long aulaId, Usuario usuario) {
        permitida(aulaId, usuario);
        // Cem mensagens mantem a resposta leve; paginacao pode substituir este limite quando o chat crescer.
        return mensagens.findTop100ByAulaIdOrderByCriadaEmAsc(aulaId).stream().map(ChatResponse::from).toList();
    }

    private Aula gerenciavel(Long id, Usuario usuario) {
        Aula aula = buscar(id);
        if (usuario.getPerfil() != Perfil.ADMIN && !aula.getProfessor().getId().equals(usuario.getId())) throw proibido();
        return aula;
    }

    private Aula permitida(Long id, Usuario usuario) {
        Aula aula = buscar(id);
        boolean professor = aula.getProfessor().getId().equals(usuario.getId());
        boolean aluno = aula.getAlunos().stream().anyMatch(item -> item.getId().equals(usuario.getId()));
        if (usuario.getPerfil() != Perfil.ADMIN && !professor && !aluno) throw proibido();
        return aula;
    }

    private Aula buscar(Long id) {
        return aulas.findById(id).orElseThrow(() -> new AppException(HttpStatus.NOT_FOUND, "Aula nao encontrada."));
    }
    private AppException proibido() { return new AppException(HttpStatus.FORBIDDEN, "Voce nao tem acesso a esta aula."); }
    private String limpar(String valor) { return valor == null ? null : valor.trim(); }
}
