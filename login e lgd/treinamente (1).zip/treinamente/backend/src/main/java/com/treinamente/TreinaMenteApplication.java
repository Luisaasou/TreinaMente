package com.treinamente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// Ponto unico de inicializacao para o Spring localizar configuracoes, servicos e rotas do projeto.
public class TreinaMenteApplication {
    public static void main(String[] args) {
        SpringApplication.run(TreinaMenteApplication.class, args);
    }
}
