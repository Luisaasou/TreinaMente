package com.treinamente.service;

import com.treinamente.exception.AppException;
import com.treinamente.model.*;
import com.treinamente.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.time.*;
import java.util.Base64;

@Service
// Emite tokens aleatorios e guarda somente o hash, reduzindo o estrago se o banco for exposto.
public class TokenService {
    public record TokenEmitido(String valor, Instant expiraEm) {}

    private final TokenAutenticacaoRepository autenticacaoRepository;
    private final TokenContaRepository contaRepository;
    private final SecureRandom random = new SecureRandom();
    private final Duration duracaoSessao;
    private final Duration duracaoConta;

    public TokenService(TokenAutenticacaoRepository autenticacaoRepository,
                        TokenContaRepository contaRepository,
                        @Value("${app.auth.session-hours:12}") long horasSessao,
                        @Value("${app.auth.account-token-minutes:30}") long minutosConta) {
        this.autenticacaoRepository = autenticacaoRepository;
        this.contaRepository = contaRepository;
        this.duracaoSessao = Duration.ofHours(horasSessao);
        this.duracaoConta = Duration.ofMinutes(minutosConta);
    }

    @Transactional
    public TokenEmitido criarSessao(Usuario usuario) {
        // O valor puro volta uma unica vez ao cliente; daqui em diante a comparacao acontece pelo hash.
        String token = novoToken();
        TokenAutenticacao entidade = new TokenAutenticacao();
        entidade.setTokenHash(hash(token));
        entidade.setUsuario(usuario);
        entidade.setExpiraEm(Instant.now().plus(duracaoSessao));
        autenticacaoRepository.save(entidade);
        return new TokenEmitido(token, entidade.getExpiraEm());
    }

    @Transactional(readOnly = true)
    public Usuario autenticar(String token) {
        if (token == null || token.isBlank()) return null;
        return autenticacaoRepository.findByTokenHashAndExpiraEmAfter(hash(token), Instant.now())
                .map(TokenAutenticacao::getUsuario)
                .filter(Usuario::isAtivo)
                .orElse(null);
    }

    @Transactional
    public void encerrar(String token) {
        if (token != null && !token.isBlank()) autenticacaoRepository.deleteByTokenHash(hash(token));
    }

    @Transactional
    public void encerrarTodas(Usuario usuario) {
        autenticacaoRepository.deleteByUsuarioId(usuario.getId());
    }

    @Transactional
    public TokenEmitido criarTokenConta(Usuario usuario, TokenConta.Tipo tipo) {
        String token = novoToken();
        TokenConta entidade = new TokenConta();
        entidade.setTokenHash(hash(token));
        entidade.setUsuario(usuario);
        entidade.setTipo(tipo);
        entidade.setExpiraEm(Instant.now().plus(duracaoConta));
        contaRepository.save(entidade);
        return new TokenEmitido(token, entidade.getExpiraEm());
    }

    @Transactional
    public Usuario consumirTokenConta(String token, TokenConta.Tipo tipo) {
        TokenConta entidade = contaRepository
                .findByTokenHashAndTipoAndUsadoEmIsNullAndExpiraEmAfter(hash(token), tipo, Instant.now())
                .orElseThrow(() -> new AppException(HttpStatus.BAD_REQUEST, "Token invalido ou expirado."));
        // Marcar o uso dentro da mesma transacao impede reutilizar links de verificacao ou recuperacao.
        entidade.setUsadoEm(Instant.now());
        return entidade.getUsuario();
    }

    private String novoToken() {
        // Trinta e dois bytes aleatorios oferecem entropia suficiente sem criar um token enorme na URL.
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String hash(String valor) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(valor.getBytes(StandardCharsets.UTF_8));
            return java.util.HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 indisponivel", exception);
        }
    }
}
