package com.treinamente.repository;

import com.treinamente.model.ConsentimentoLgpd;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ConsentimentoLgpdRepository extends JpaRepository<ConsentimentoLgpd, Long> {
    List<ConsentimentoLgpd> findByUsuarioIdOrderByAceitoEmDesc(Long usuarioId);
}
