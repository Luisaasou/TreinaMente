package com.treinamente.repository;

import com.treinamente.model.Instituicao;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

// O codigo e a chave humana usada para reencontrar a instituicao durante o cadastro.
public interface InstituicaoRepository extends JpaRepository<Instituicao, Long> {
    Optional<Instituicao> findByCodigoIgnoreCase(String codigo);
}
