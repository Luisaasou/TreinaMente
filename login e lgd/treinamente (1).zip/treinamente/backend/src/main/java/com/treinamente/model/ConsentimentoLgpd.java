package com.treinamente.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "consentimentos_lgpd")
// Cada aceite vira uma linha propria (nunca sobrescrita), formando o historico exigido pela LGPD
// para comprovar quando e em qual versao do documento o titular consentiu.
public class ConsentimentoLgpd {
    // Mantido separado do Termo de Uso: o titular pode revisar cada finalidade de tratamento isoladamente.
    public enum Tipo { TERMO_USO, POLITICA_PRIVACIDADE }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Tipo tipo;

    @Column(name = "versao_documento", nullable = false, length = 20)
    private String versaoDocumento;

    @Column(name = "aceito_em", nullable = false, updatable = false)
    private Instant aceitoEm = Instant.now();

    @Column(length = 64)
    private String ip;

    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public Tipo getTipo() { return tipo; }
    public void setTipo(Tipo tipo) { this.tipo = tipo; }
    public String getVersaoDocumento() { return versaoDocumento; }
    public void setVersaoDocumento(String versaoDocumento) { this.versaoDocumento = versaoDocumento; }
    public Instant getAceitoEm() { return aceitoEm; }
    public String getIp() { return ip; }
    public void setIp(String ip) { this.ip = ip; }
}
