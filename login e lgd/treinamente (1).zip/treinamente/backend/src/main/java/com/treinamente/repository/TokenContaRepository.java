package com.treinamente.repository;

import com.treinamente.model.TokenConta;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.Optional;

// A consulta exige tipo, prazo e uso pendente para aceitar somente o link correto uma vez.
public interface TokenContaRepository extends JpaRepository<TokenConta, Long> {
    Optional<TokenConta> findByTokenHashAndTipoAndUsadoEmIsNullAndExpiraEmAfter(
            String tokenHash, TokenConta.Tipo tipo, Instant agora);
}
