package com.treinamente.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.treinamente.dto.ApiDtos.RespostaIaResponse;
import com.treinamente.exception.AppException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.*;
import java.util.regex.Pattern;

@Service
// Encapsula o Gemini e acrescenta limites educacionais antes de devolver qualquer resposta ao estudante.
public class IaEducacionalService {
    private static final Pattern ALERTA_SAUDE = Pattern.compile(
            "(?i)\\b(dor|les[aã]o|machucad[oa]|diagn[oó]stico|tratamento|rem[eé]dio|cirurgia|coluna|joelho)\\b");
    private static final String AVISO = "Conteudo educacional. Nao substitui avaliacao de profissional de saude.";
    private final RestClient restClient;
    private final String apiKey;
    private final String model;

    public IaEducacionalService(RestClient.Builder builder,
                                @Value("${app.gemini.api-key:}") String apiKey,
                                @Value("${app.gemini.model:gemini-2.0-flash}") String model) {
        this.restClient = builder.baseUrl("https://generativelanguage.googleapis.com").build();
        this.apiKey = apiKey;
        this.model = model;
    }

    public RespostaIaResponse perguntar(String pergunta) {
        // Sem chave real, falhamos de forma explicita em vez de simular uma resposta de IA.
        if (apiKey.isBlank()) {
            throw new AppException(HttpStatus.SERVICE_UNAVAILABLE, "Integracao Gemini nao configurada.");
        }
        // Palavras de saude reforcam o aviso, mas nao tentam substituir uma avaliacao profissional.
        boolean alerta = ALERTA_SAUDE.matcher(pergunta).find();
        String instrucao = "Voce e um tutor de Educacao Fisica para estudantes universitarios. " +
                "Explique conceitos com clareza, cite limites e incertezas e nunca invente fontes. " +
                "Nao diagnostique, nao prescreva tratamento e, diante de dor ou lesao, recomende avaliacao profissional. " +
                "Responda em portugues do Brasil. Pergunta: " + pergunta;
        Map<String, Object> corpo = Map.of("contents", List.of(Map.of("parts", List.of(Map.of("text", instrucao)))));
        try {
            JsonNode resposta = restClient.post()
                    .uri(uri -> uri.path("/v1beta/models/{model}:generateContent").queryParam("key", apiKey).build(model))
                    .body(corpo).retrieve().body(JsonNode.class);
            // O caminho tolerante evita NullPointerException quando o provedor mudar ou recusar a resposta.
            String texto = resposta == null ? "" : resposta.at("/candidates/0/content/parts/0/text").asText("");
            if (texto.isBlank()) throw new AppException(HttpStatus.BAD_GATEWAY, "A IA nao retornou uma resposta utilizavel.");
            if (alerta) texto = texto + "\n\n" + AVISO;
            return new RespostaIaResponse(texto, alerta, alerta ? AVISO : null);
        } catch (AppException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            throw new AppException(HttpStatus.BAD_GATEWAY, "Falha temporaria na integracao com o Gemini.");
        }
    }
}
