package com.treinamente.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "tokens_conta")
// Token de uso unico para acoes sensiveis, separado das sessoes comuns de navegacao.
public class TokenConta {
    // O tipo impede usar um link de verificacao como se fosse recuperacao de senha.
    public enum Tipo { VERIFICACAO_EMAIL, RECUPERACAO_SENHA }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "token_hash", nullable = false, unique = true, length = 64)
    private String tokenHash;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Tipo tipo;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;
    @Column(name = "expira_em", nullable = false)
    private Instant expiraEm;
    @Column(name = "usado_em")
    private Instant usadoEm;
    @Column(name = "criado_em", nullable = false, updatable = false)
    private Instant criadoEm = Instant.now();

    public Long getId() { return id; }
    public String getTokenHash() { return tokenHash; }
    public void setTokenHash(String tokenHash) { this.tokenHash = tokenHash; }
    public Tipo getTipo() { return tipo; }
    public void setTipo(Tipo tipo) { this.tipo = tipo; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public Instant getExpiraEm() { return expiraEm; }
    public void setExpiraEm(Instant expiraEm) { this.expiraEm = expiraEm; }
    public Instant getUsadoEm() { return usadoEm; }
    public void setUsadoEm(Instant usadoEm) { this.usadoEm = usadoEm; }
    public Instant getCriadoEm() { return criadoEm; }
}
