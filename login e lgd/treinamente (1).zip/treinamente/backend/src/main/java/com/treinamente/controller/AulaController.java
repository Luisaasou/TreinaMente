package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.model.Usuario;
import com.treinamente.service.AulaService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/aulas")
// Expoe o fluxo da aula; o servico confere dono, matricula e instituicao em cada operacao.
public class AulaController {
    private final AulaService aulas;
    public AulaController(AulaService aulas) { this.aulas = aulas; }

    @PostMapping
    @PreAuthorize("hasAnyRole('PROFESSOR','ADMIN')")
    public ResponseEntity<AulaResponse> criar(@Valid @RequestBody CriarAulaRequest request,
                                               @AuthenticationPrincipal Usuario usuario) {
        return ResponseEntity.status(HttpStatus.CREATED).body(aulas.criar(request, usuario));
    }
    @GetMapping
    public List<AulaResponse> listar(@AuthenticationPrincipal Usuario usuario) { return aulas.listar(usuario); }
    @GetMapping("/{id}")
    public AulaResponse detalhe(@PathVariable Long id, @AuthenticationPrincipal Usuario usuario) {
        return aulas.detalhe(id, usuario);
    }
    @PutMapping("/{id}/conteudo")
    @PreAuthorize("hasAnyRole('PROFESSOR','ADMIN')")
    public AulaResponse conteudo(@PathVariable Long id, @Valid @RequestBody AtualizarConteudoRequest request,
                                  @AuthenticationPrincipal Usuario usuario) {
        return aulas.atualizarConteudo(id, request, usuario);
    }
    @PostMapping("/{id}/alunos")
    @PreAuthorize("hasAnyRole('PROFESSOR','ADMIN')")
    public AulaResponse matricular(@PathVariable Long id, @Valid @RequestBody MatricularAlunoRequest request,
                                    @AuthenticationPrincipal Usuario usuario) {
        return aulas.matricular(id, request, usuario);
    }
    @GetMapping("/{id}/mensagens")
    public List<ChatResponse> mensagens(@PathVariable Long id, @AuthenticationPrincipal Usuario usuario) {
        return aulas.listarMensagens(id, usuario);
    }
    @PostMapping("/{id}/mensagens")
    public ResponseEntity<ChatResponse> enviar(@PathVariable Long id, @Valid @RequestBody EnviarMensagemRequest request,
                                                @AuthenticationPrincipal Usuario usuario) {
        return ResponseEntity.status(HttpStatus.CREATED).body(aulas.enviarMensagem(id, request, usuario));
    }
}
