package com.treinamente.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.treinamente.dto.ApiDtos.*;
import com.treinamente.exception.AppException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.*;
import java.util.stream.StreamSupport;

@Service
// Faz a pesquisa no servidor para nunca expor a chave do Google no JavaScript publico.
public class PesquisaGoogleService {
    private final RestClient restClient;
    private final String apiKey;
    private final String engineId;

    public PesquisaGoogleService(RestClient.Builder builder,
                                 @Value("${app.google-search.api-key:}") String apiKey,
                                 @Value("${app.google-search.engine-id:}") String engineId) {
        this.restClient = builder.baseUrl("https://customsearch.googleapis.com").build();
        this.apiKey = apiKey;
        this.engineId = engineId;
    }

    public PesquisaResponse pesquisar(String consulta) {
        // Configuracao ausente e diferente de uma busca vazia, por isso retornamos indisponibilidade.
        if (apiKey.isBlank() || engineId.isBlank()) {
            throw new AppException(HttpStatus.SERVICE_UNAVAILABLE, "Pesquisa Google nao configurada.");
        }
        try {
            JsonNode resposta = restClient.get().uri(uri -> uri.path("/customsearch/v1")
                    .queryParam("key", apiKey).queryParam("cx", engineId).queryParam("q", consulta)
                    // Poucos resultados e SafeSearch ativo deixam a ferramenta adequada ao contexto academico.
                    .queryParam("num", 5).queryParam("safe", "active").build()).retrieve().body(JsonNode.class);
            JsonNode itens = resposta == null ? null : resposta.get("items");
            List<PesquisaItem> resultados = itens == null ? List.of() : StreamSupport.stream(itens.spliterator(), false)
                    .map(item -> new PesquisaItem(item.path("title").asText(), item.path("link").asText(),
                            item.path("snippet").asText())).toList();
            return new PesquisaResponse(consulta, resultados);
        } catch (RuntimeException exception) {
            throw new AppException(HttpStatus.BAD_GATEWAY, "Falha temporaria na pesquisa Google.");
        }
    }
}
