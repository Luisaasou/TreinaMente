package com.treinamente.model;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "aulas")
// Representa o espaco compartilhado entre um professor e os estudantes matriculados.
public class Aula {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 160)
    private String titulo;
    @Column(length = 1000)
    private String descricao;
    @Lob
    @Column(name = "conteudo_atual")
    private String conteudoAtual;
    @Column(nullable = false)
    private boolean ativa = true;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "professor_id", nullable = false)
    private Usuario professor;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "instituicao_id", nullable = false)
    private Instituicao instituicao;
    @ManyToMany
    @JoinTable(name = "aula_alunos", joinColumns = @JoinColumn(name = "aula_id"), inverseJoinColumns = @JoinColumn(name = "aluno_id"))
    // LinkedHashSet evita matricula duplicada e mantem uma ordem previsivel nas respostas.
    private Set<Usuario> alunos = new LinkedHashSet<>();
    @Version
    private long versao;
    @Column(name = "criada_em", nullable = false, updatable = false)
    private Instant criadaEm = Instant.now();
    @Column(name = "atualizada_em", nullable = false)
    private Instant atualizadaEm = Instant.now();

    @PreUpdate
    // A data e atualizada na entidade para funcionar igual em qualquer banco suportado.
    void atualizarData() { atualizadaEm = Instant.now(); }
    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getConteudoAtual() { return conteudoAtual; }
    public void setConteudoAtual(String conteudoAtual) { this.conteudoAtual = conteudoAtual; }
    public boolean isAtiva() { return ativa; }
    public void setAtiva(boolean ativa) { this.ativa = ativa; }
    public Usuario getProfessor() { return professor; }
    public void setProfessor(Usuario professor) { this.professor = professor; }
    public Instituicao getInstituicao() { return instituicao; }
    public void setInstituicao(Instituicao instituicao) { this.instituicao = instituicao; }
    public Set<Usuario> getAlunos() { return alunos; }
    public long getVersao() { return versao; }
    public Instant getCriadaEm() { return criadaEm; }
    public Instant getAtualizadaEm() { return atualizadaEm; }
}
