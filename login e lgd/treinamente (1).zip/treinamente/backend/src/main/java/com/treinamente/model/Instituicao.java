package com.treinamente.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "instituicoes")
// O codigo estavel agrupa contas sem depender de variacoes no nome exibido da instituicao.
public class Instituicao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 160)
    private String nome;
    @Column(nullable = false, unique = true, length = 40)
    private String codigo;
    @Column(name = "criado_em", nullable = false, updatable = false)
    private Instant criadoEm = Instant.now();

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public Instant getCriadoEm() { return criadoEm; }
}
