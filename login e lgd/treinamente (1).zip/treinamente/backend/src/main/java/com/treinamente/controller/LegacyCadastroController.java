package com.treinamente.controller;

import com.treinamente.dto.ApiDtos.*;
import com.treinamente.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
// Preserva o endpoint do prototipo antigo enquanto reaproveita o cadastro seguro atual.
public class LegacyCadastroController {
    private final AuthService auth;
    public LegacyCadastroController(AuthService auth) { this.auth = auth; }
    @PostMapping("/cadastro")
    public ResponseEntity<RegistroResponse> cadastrar(@Valid @RequestBody RegistroRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(auth.registrar(request));
    }
}
