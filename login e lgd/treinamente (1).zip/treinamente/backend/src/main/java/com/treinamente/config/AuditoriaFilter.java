package com.treinamente.config;

import com.treinamente.model.Usuario;
import com.treinamente.service.AuditoriaService;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component
// Roda depois da AutenticacaoFilter para ja enxergar a identidade resolvida; registra automaticamente
// todo acesso autenticado (rota, metodo e status) sem exigir que cada controller chame a auditoria manualmente.
public class AuditoriaFilter extends OncePerRequestFilter {
    private final AuditoriaService auditoria;

    public AuditoriaFilter(AuditoriaService auditoria) { this.auditoria = auditoria; }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        chain.doFilter(request, response);
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) return;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth != null && auth.getPrincipal() instanceof Usuario usuario)) return;
        auditoria.registrarAcesso(usuario, request.getMethod(), request.getRequestURI(), response.getStatus());
    }
}
