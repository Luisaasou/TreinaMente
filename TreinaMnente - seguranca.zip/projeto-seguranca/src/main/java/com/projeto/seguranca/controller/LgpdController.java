package com.projeto.seguranca.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Disponibiliza (publicamente) as informacoes de LGPD: termo de uso e politica de privacidade. */
@RestController
@RequestMapping("/api/lgpd")
public class LgpdController {

    @GetMapping("/informacoes")
    public Map<String, Object> informacoes() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("versao", "1.0");
        map.put("termoDeUso", "/termos-de-uso.html");
        map.put("politicaDePrivacidade", "/politica-de-privacidade.html");
        map.put("dadosColetados", List.of("nome", "e-mail", "senha (armazenada apenas como hash)",
                "endereço IP e ações realizadas (logs de auditoria)"));
        map.put("finalidades", List.of("autenticação e controle de acesso", "segurança e auditoria",
                "cumprimento de obrigação legal"));
        map.put("baseLegal", "Consentimento (Art. 7º, I) e cumprimento de obrigação legal (Art. 7º, II)");
        map.put("direitosDoTitular", Map.of(
                "acesso", "GET /api/users/me",
                "eliminacao", "DELETE /api/users/me",
                "outros", "Confirmação, correção, portabilidade e revogação: contato@projeto.com"));
        return map;
    }
}
