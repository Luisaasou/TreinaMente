package com.projeto.seguranca.controller;

import com.projeto.seguranca.model.User;
import com.projeto.seguranca.repository.UserRepository;
import com.projeto.seguranca.service.AuditService;
import com.projeto.seguranca.util.RequestUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/** Direitos do titular (LGPD art. 18): acesso aos dados e eliminacao. */
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserRepository userRepository;
    private final AuditService auditService;

    public UserController(UserRepository userRepository, AuditService auditService) {
        this.userRepository = userRepository;
        this.auditService = auditService;
    }

    @GetMapping("/me")
    public Map<String, Object> me(Authentication auth) {
        User u = userRepository.findByEmail(auth.getName()).orElseThrow();
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("name", u.getName());
        map.put("email", u.getEmail());
        map.put("role", u.getRole());
        map.put("termsAccepted", u.isTermsAccepted());
        map.put("termsAcceptedAt", u.getTermsAcceptedAt());
        map.put("createdAt", u.getCreatedAt());
        return map;
    }

    @DeleteMapping("/me")
    @Transactional
    public ResponseEntity<Void> deleteMe(Authentication auth, HttpServletRequest request) {
        User u = userRepository.findByEmail(auth.getName()).orElseThrow();
        userRepository.delete(u);
        auditService.log(auth.getName(), "CONTA_EXCLUIDA_LGPD",
                "Titular solicitou eliminação dos dados pessoais", RequestUtils.clientIp(request), 204);
        return ResponseEntity.noContent().build();
    }
}
