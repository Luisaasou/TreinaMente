package com.projeto.seguranca.model;

public enum Role {
    USER, ADMIN
}
