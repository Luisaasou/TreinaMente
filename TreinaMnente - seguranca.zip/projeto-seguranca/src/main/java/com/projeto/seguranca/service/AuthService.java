package com.projeto.seguranca.service;

import com.projeto.seguranca.dto.AuthResponse;
import com.projeto.seguranca.dto.LoginRequest;
import com.projeto.seguranca.dto.RegisterRequest;
import com.projeto.seguranca.model.Role;
import com.projeto.seguranca.model.User;
import com.projeto.seguranca.repository.UserRepository;
import com.projeto.seguranca.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final AuditService auditService;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager, JwtService jwtService,
                       AuditService auditService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
        this.auditService = auditService;
    }

    public AuthResponse register(RegisterRequest req, String ip) {
        if (!req.acceptTerms()) {
            throw new IllegalArgumentException("É necessário aceitar os Termos de Uso e a Política de Privacidade (LGPD)");
        }
        String email = req.email().trim().toLowerCase();
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("E-mail já cadastrado");
        }

        User user = new User();
        user.setName(req.name().trim());
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(req.password()));
        user.setRole(Role.USER);
        user.setTermsAccepted(true);
        user.setTermsAcceptedAt(LocalDateTime.now());
        userRepository.save(user);

        auditService.log(email, "REGISTRO_USUARIO", "Novo usuário cadastrado com consentimento LGPD", ip, 201);
        return buildResponse(user);
    }

    public AuthResponse login(LoginRequest req, String ip) {
        String email = req.email().trim().toLowerCase();
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, req.password()));
        } catch (AuthenticationException e) {
            auditService.log(email, "LOGIN_FALHA", "Credenciais inválidas", ip, 401);
            throw new BadCredentialsException("Credenciais inválidas");
        }
        User user = userRepository.findByEmail(email).orElseThrow();
        auditService.log(email, "LOGIN_SUCESSO", "Autenticação realizada", ip, 200);
        return buildResponse(user);
    }

    private AuthResponse buildResponse(User user) {
        String token = jwtService.generateToken(user.getEmail(), user.getRole().name());
        return new AuthResponse(token, "Bearer", jwtService.getExpirationMs(),
                user.getName(), user.getEmail(), user.getRole().name());
    }
}
