package com.projeto.seguranca.dto;

public record AuthResponse(String token, String type, long expiresInMs, String name, String email, String role) {}
