package com.projeto.seguranca.audit;

import com.projeto.seguranca.service.AuditService;
import com.projeto.seguranca.util.RequestUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * AUDITORIA DE ACESSOS: registra toda chamada a /api/** (quem, o que, de onde, resultado).
 * Nao grava corpo da requisicao nem query string (podem conter senhas/dados pessoais).
 */
@Component
public class AuditInterceptor implements HandlerInterceptor {

    private final AuditService auditService;

    public AuditInterceptor(AuditService auditService) {
        this.auditService = auditService;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String user = (auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken))
                ? auth.getName() : "anonimo";
        auditService.log(user, "ACESSO_API",
                request.getMethod() + " " + request.getRequestURI(),
                RequestUtils.clientIp(request), response.getStatus());
    }
}
