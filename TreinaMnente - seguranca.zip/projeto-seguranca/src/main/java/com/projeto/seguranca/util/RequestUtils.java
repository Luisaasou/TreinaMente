package com.projeto.seguranca.util;

import jakarta.servlet.http.HttpServletRequest;

public final class RequestUtils {
    private RequestUtils() {}

    /** Usa getRemoteAddr (X-Forwarded-For pode ser forjado; so use se houver proxy confiavel). */
    public static String clientIp(HttpServletRequest request) {
        return request.getRemoteAddr();
    }
}
