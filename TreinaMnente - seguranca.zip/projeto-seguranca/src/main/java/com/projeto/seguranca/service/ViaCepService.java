package com.projeto.seguranca.service;

import com.projeto.seguranca.dto.CepResponse;
import com.projeto.seguranca.exception.ExternalApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.NoSuchElementException;

/** Integracao com a API externa ViaCEP (https://viacep.com.br). Ver docs/INTEGRACAO_API_EXTERNA.md */
@Service
public class ViaCepService {

    private final RestClient client;

    public ViaCepService(@Value("${app.external.viacep.url}") String baseUrl) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(3000);
        factory.setReadTimeout(5000);
        this.client = RestClient.builder().baseUrl(baseUrl).requestFactory(factory).build();
    }

    public CepResponse buscar(String cep) {
        String digits = cep == null ? "" : cep.replaceAll("\\D", "");
        if (digits.length() != 8) {
            throw new IllegalArgumentException("CEP inválido: informe 8 dígitos");
        }
        try {
            CepResponse response = client.get().uri("/{cep}/json/", digits).retrieve().body(CepResponse.class);
            if (response == null || Boolean.TRUE.equals(response.erro())) {
                throw new NoSuchElementException("CEP não encontrado");
            }
            return response;
        } catch (RestClientException e) {
            throw new ExternalApiException("Serviço de CEP indisponível no momento", e);
        }
    }
}
