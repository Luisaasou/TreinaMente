package com.projeto.seguranca.repository;

import com.projeto.seguranca.model.AuditLog;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findAllByOrderByOccurredAtDesc(Pageable pageable);
    List<AuditLog> findByUsernameOrderByOccurredAtDesc(String username, Pageable pageable);
}
