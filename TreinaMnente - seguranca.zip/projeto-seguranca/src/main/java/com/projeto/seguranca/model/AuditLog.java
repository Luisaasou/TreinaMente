package com.projeto.seguranca.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime occurredAt = LocalDateTime.now();

    @Column(length = 160)
    private String username;

    @Column(nullable = false, length = 60)
    private String action;

    @Column(length = 500)
    private String details;

    @Column(length = 64)
    private String ipAddress;

    private Integer httpStatus;

    public AuditLog() {}

    public AuditLog(String username, String action, String details, String ipAddress, Integer httpStatus) {
        this.username = username;
        this.action = action;
        this.details = details;
        this.ipAddress = ipAddress;
        this.httpStatus = httpStatus;
    }

    public Long getId() { return id; }
    public LocalDateTime getOccurredAt() { return occurredAt; }
    public String getUsername() { return username; }
    public String getAction() { return action; }
    public String getDetails() { return details; }
    public String getIpAddress() { return ipAddress; }
    public Integer getHttpStatus() { return httpStatus; }
}
