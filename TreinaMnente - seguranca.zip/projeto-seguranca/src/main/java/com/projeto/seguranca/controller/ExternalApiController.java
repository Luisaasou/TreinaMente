package com.projeto.seguranca.controller;

import com.projeto.seguranca.dto.CepResponse;
import com.projeto.seguranca.service.ViaCepService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/external")
public class ExternalApiController {

    private final ViaCepService viaCepService;

    public ExternalApiController(ViaCepService viaCepService) {
        this.viaCepService = viaCepService;
    }

    @GetMapping("/cep/{cep}")
    public CepResponse buscarCep(@PathVariable String cep) {
        return viaCepService.buscar(cep);
    }
}
