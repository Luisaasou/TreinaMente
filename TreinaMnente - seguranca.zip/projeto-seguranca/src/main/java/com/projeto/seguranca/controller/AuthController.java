package com.projeto.seguranca.controller;

import com.projeto.seguranca.dto.AuthResponse;
import com.projeto.seguranca.dto.LoginRequest;
import com.projeto.seguranca.dto.RegisterRequest;
import com.projeto.seguranca.service.AuthService;
import com.projeto.seguranca.util.RequestUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest body, HttpServletRequest request) {
        return ResponseEntity.status(201).body(authService.register(body, RequestUtils.clientIp(request)));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest body, HttpServletRequest request) {
        return ResponseEntity.ok(authService.login(body, RequestUtils.clientIp(request)));
    }
}
