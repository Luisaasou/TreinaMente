package com.projeto.seguranca.config;

import com.projeto.seguranca.security.JwtAuthenticationFilter;
import com.projeto.seguranca.service.AuditService;
import com.projeto.seguranca.util.RequestUtils;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtFilter;
    private final AuditService auditService;

    public SecurityConfig(JwtAuthenticationFilter jwtFilter, AuditService auditService) {
        this.jwtFilter = jwtFilter;
        this.auditService = auditService;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // API stateless com JWT (sem cookies de sessao)
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .headers(h -> h.frameOptions(f -> f.sameOrigin())) // necessario para o H2 console
            .authorizeHttpRequests(auth -> auth
                // AUTORIZACAO: rotas publicas
                .requestMatchers(ant("/", "/*.html", "/error", "/api/auth/**", "/api/lgpd/**", "/h2-console/**")).permitAll()
                // AUTORIZACAO: somente ADMIN
                .requestMatchers(ant("/api/audit/**")).hasRole("ADMIN")
                // Demais rotas: qualquer usuario autenticado
                .anyRequest().authenticated())
            .exceptionHandling(e -> e
                .authenticationEntryPoint((req, res, ex) -> {
                    auditService.log("anonimo", "ACESSO_NAO_AUTENTICADO",
                            req.getMethod() + " " + req.getRequestURI(), RequestUtils.clientIp(req), 401);
                    writeJson(res, 401, "Não autenticado");
                })
                .accessDeniedHandler((req, res, ex) -> {
                    String user = SecurityContextHolder.getContext().getAuthentication() != null
                            ? SecurityContextHolder.getContext().getAuthentication().getName() : "anonimo";
                    auditService.log(user, "ACESSO_NEGADO",
                            req.getMethod() + " " + req.getRequestURI(), RequestUtils.clientIp(req), 403);
                    writeJson(res, 403, "Acesso negado");
                }))
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    /** CRIPTOGRAFIA: senhas armazenadas com hash BCrypt (com salt). */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    private static RequestMatcher[] ant(String... patterns) {
        return Arrays.stream(patterns).map(AntPathRequestMatcher::new).toArray(RequestMatcher[]::new);
    }

    private static void writeJson(HttpServletResponse res, int status, String message) throws java.io.IOException {
        res.setStatus(status);
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setCharacterEncoding("UTF-8");
        res.getWriter().write("{\"status\":" + status + ",\"message\":\"" + message + "\"}");
    }
}
