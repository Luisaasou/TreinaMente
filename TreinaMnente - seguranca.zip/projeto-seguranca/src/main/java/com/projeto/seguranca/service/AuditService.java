package com.projeto.seguranca.service;

import com.projeto.seguranca.model.AuditLog;
import com.projeto.seguranca.repository.AuditLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger("AUDIT");

    private final AuditLogRepository repository;

    public AuditService(AuditLogRepository repository) {
        this.repository = repository;
    }

    /** Registra no banco e tambem no log da aplicacao. Falha na auditoria nao derruba a requisicao. */
    public void log(String username, String action, String details, String ip, Integer status) {
        try {
            repository.save(new AuditLog(username, action, details, ip, status));
            log.info("user={} action={} details={} ip={} status={}", username, action, details, ip, status);
        } catch (Exception e) {
            log.error("Falha ao gravar auditoria: {}", e.getMessage());
        }
    }

    public List<AuditLog> list(String username, int limit) {
        PageRequest page = PageRequest.of(0, Math.max(1, Math.min(limit, 500)));
        return (username == null || username.isBlank())
                ? repository.findAllByOrderByOccurredAtDesc(page)
                : repository.findByUsernameOrderByOccurredAtDesc(username, page);
    }
}
