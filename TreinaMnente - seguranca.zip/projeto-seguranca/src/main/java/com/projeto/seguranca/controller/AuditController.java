package com.projeto.seguranca.controller;

import com.projeto.seguranca.model.AuditLog;
import com.projeto.seguranca.service.AuditService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Consulta de logs de auditoria - somente ADMIN (regra definida no SecurityConfig). */
@RestController
@RequestMapping("/api/audit")
public class AuditController {

    private final AuditService auditService;

    public AuditController(AuditService auditService) {
        this.auditService = auditService;
    }

    @GetMapping
    public List<AuditLog> list(@RequestParam(required = false) String user,
                               @RequestParam(defaultValue = "100") int limit) {
        return auditService.list(user, limit);
    }
}
