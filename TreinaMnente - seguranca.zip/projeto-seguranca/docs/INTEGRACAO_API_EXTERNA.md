# Integração com API externa – Projeto lógico + documentação

## 1. Objetivo
Permitir que o sistema consulte dados de endereço a partir de um CEP, evitando digitação manual e reduzindo erros de cadastro.

## 2. API escolhida: ViaCEP
| Item | Descrição |
|---|---|
| Provedor | ViaCEP (https://viacep.com.br) |
| Tipo | REST / JSON, pública e gratuita |
| Autenticação | Não exige chave |
| Endpoint externo | `GET https://viacep.com.br/ws/{cep}/json/` |
| Justificativa | Sem custo, sem cadastro, ampla documentação e sem envio de dado pessoal (apenas o CEP) |

> Se o seu orientador exigir outra API (ex.: pagamento, e-mail, mapas), basta trocar a classe `ViaCepService` e o DTO; a arquitetura abaixo se mantém.

## 3. Projeto lógico

### 3.1 Componentes
| Camada | Classe | Responsabilidade |
|---|---|---|
| Controller | `ExternalApiController` | Expõe `GET /api/external/cep/{cep}` (exige JWT) |
| Service | `ViaCepService` | Valida o CEP, chama a API externa, trata erros/timeouts |
| DTO | `CepResponse` | Mapeia o JSON retornado |
| Segurança | `SecurityConfig` + `JwtAuthenticationFilter` | Só usuários autenticados consomem a integração |
| Auditoria | `AuditInterceptor` | Registra cada consulta feita |

### 3.2 Diagrama de sequência
```mermaid
sequenceDiagram
    participant C as Cliente (Postman/Front)
    participant API as Nossa API (Spring Boot)
    participant V as ViaCEP
    C->>API: GET /api/external/cep/01001000 (Bearer JWT)
    API->>API: Valida JWT e perfil
    API->>API: Valida CEP (8 dígitos)
    API->>V: GET /ws/01001000/json/
    V-->>API: 200 JSON (endereço)
    API->>API: Registra auditoria (ACESSO_API)
    API-->>C: 200 JSON (endereço)
```

## 4. Contrato da nossa API

**Requisição**
```
GET /api/external/cep/01001000
Authorization: Bearer <token>
```

**Resposta 200**
```json
{
  "cep": "01001-000",
  "logradouro": "Praça da Sé",
  "complemento": "lado ímpar",
  "bairro": "Sé",
  "localidade": "São Paulo",
  "uf": "SP",
  "erro": null
}
```

| Situação | HTTP | Mensagem |
|---|---|---|
| CEP com formato inválido | 400 | CEP inválido: informe 8 dígitos |
| Sem token / token inválido | 401 | Não autenticado |
| CEP inexistente | 404 | CEP não encontrado |
| ViaCEP fora do ar / timeout | 502 | Serviço de CEP indisponível no momento |

## 5. Decisões técnicas
- **Timeouts:** conexão 3 s e leitura 5 s, para não travar a aplicação se a API externa demorar.
- **Tratamento de falhas:** erros da API externa viram HTTP 502 com mensagem amigável (sem vazar detalhes internos).
- **Configuração externa:** URL base em `application.properties` (`app.external.viacep.url`).
- **Validação de entrada:** o CEP é limpo (`\D`) e validado antes de sair da aplicação, evitando requisições inúteis e injeção de caminho.
- **Cliente HTTP:** `RestClient` (Spring 6.1+).

## 6. Segurança e LGPD
- Somente o **CEP** é enviado ao provedor externo; nenhum dado pessoal (nome, e-mail, IP do usuário).
- O compartilhamento está declarado na Política de Privacidade.
- Toda consulta gera registro de auditoria.

## 7. Como testar
1. Faça login e copie o token (ver README).
2. `curl -H "Authorization: Bearer <token>" http://localhost:8080/api/external/cep/01001000`
3. Teste os erros: CEP `123`, CEP `99999999`, e sem o header Authorization.

## 8. Evoluções futuras
Cache das respostas (Caffeine), Resilience4j (retry e circuit breaker) e testes com WireMock.
